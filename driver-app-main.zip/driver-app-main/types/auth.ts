type SuccessLogin = {
  token: string | null;
  refreshToken: string | null;
  expiredIn: string | null;
  user: Driver | null;
};

interface Tokens {
  accessToken: string | null;
  refreshToken: string | null;
  expiredIn: Date | null;
}

type TokensAction = {
  type: string;
  token: Tokens;
};

type DispatchType = (args: TokensAction) => TokensAction;

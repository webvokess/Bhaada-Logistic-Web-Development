package main

import "bhaada-backend/server"

func main() {
	server.Init()
}

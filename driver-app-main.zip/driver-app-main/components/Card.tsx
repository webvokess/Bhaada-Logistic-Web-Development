import { Image, StyleSheet, Text, View } from "react-native";
import React from "react";
import tw from "tailwind-react-native-classnames";
import truck from "../assets/truck.png";

const Card = () => {
  return (
    <View
      style={[
        tw`rounded-xl mx-auto justify-center items-center`,
        { backgroundColor: "#A7EFFF", width: 300, height: 350 },
      ]}
      elevation={5}
    >
      <Image source={truck} style={tw`absolute right-7 top-7`} />
      <Text
        style={[
          tw`text-xl`,
          { fontFamily: "Mulish_700Bold", color: "#3E4958" },
        ]}
      >
        Earn well
      </Text>
      <Text
        style={[
          tw`text-xl`,
          { fontFamily: "Mulish_700Bold", color: "#3E4958" },
        ]}
      >
        with
      </Text>
      <Text
        style={[
          tw`text-xl`,
          { fontFamily: "Mulish_700Bold", color: "#3E4958" },
        ]}
      >
        The Bhaada App
      </Text>
    </View>
  );
};

export default Card;

const styles = StyleSheet.create({});

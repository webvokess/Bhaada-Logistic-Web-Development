# driver-app

### [Link to the design file](https://www.figma.com/file/ubHfC5skedLpcDlCGli8IS/Bhada-Project?node-id=0%3A1)

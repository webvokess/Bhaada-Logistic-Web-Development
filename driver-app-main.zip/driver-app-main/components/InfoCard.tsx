import { StyleSheet, Text, View, Image, TouchableOpacity } from "react-native";
import React from "react";
import tw from "tailwind-react-native-classnames";
import Dash from "react-native-dash";
import user from "../assets/user.png";
import { useNavigation } from "@react-navigation/native";

const InfoCard = ({
  vehicle,
  vehicleNumber,
  image,
  rideTime,
  from,
  to,
  cancel,
}) => {
  const navigation = useNavigation();
  return (
    <View
      style={tw`bg-gray-100 mt-2 flex-row justify-around px-5 py-3 mx-2`}
      elevation={5}
    >
      {/* <Image source={image} style={{ width: 30, height: 30 }} /> */}
      <View>
        <Text style={tw`text-base font-semibold`}>{rideTime}</Text>
        <Text>
          {vehicle}: {vehicleNumber}
        </Text>
        <View style={tw`pt-1`}>
          <Text style={tw`text-gray-500`}>{from}</Text>
          <Text style={tw`text-green-700 text-3xl font-bold -mt-3`}>.</Text>
          <Dash
            style={{
              width: 1,
              height: 20,
              flexDirection: "column",
              paddingLeft: 3,
            }}
            dashColor="grey"
          />
          <Text style={tw`text-red-700 text-3xl font-bold -mt-3`}>.</Text>
          <Text style={tw`text-gray-500`}>{to}</Text>
        </View>
      </View>
      <TouchableOpacity onPress={() => navigation.navigate("IndividualCard")}>
        <Image source={user} style={{ width: 70, height: 70 }} />
      </TouchableOpacity>
    </View>
  );
};

export default InfoCard;

const styles = StyleSheet.create({});

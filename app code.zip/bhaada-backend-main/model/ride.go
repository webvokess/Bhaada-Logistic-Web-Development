package model

import "time"

type Ride struct {
	Id          int64     `json:"id" bson:"_id"`
	UserId      int64     `json:"user_id" bson:"user_id"`
	DriverId    int64     `json:"driver_id" bson:"driver_id"`
	Source      int64     `json:"source" bson:"source"`
	Destination int64     `json:"destination" bson:"destination"`
	CreatedAt   time.Time `json:"created_at" bson:"created_at"`
	UpdatedAt   time.Time `json:"updated_at" bson:"updated_at"`

	RideTime         time.Time     `json:"ride_time" bson:"ride_time"`
	ExpectedDistance float64       `json:"expected_distance" bson:"expected_distance"`
	ExpectedTime     time.Duration `json:"expected_time" bson:"expected_time"`

	ItemWeight float64 `json:"item_weight" bson:"item_weight"`
	Item       int64   `json:"item_type" bson:"item_type"`
	Vehicle    int64   `json:"vehicle" bson:"vehicle"`

	Price float64 `json:"price" bson:"price"`

	Status int64 `json:"status" bson:"status"` // 0: pending, 1: accepted, 2: completed, 3: cancelled
	Rating int64 `json:"rating" bson:"rating"` // 0: no rating, 1: 1 star, 2: 2 stars, 3: 3 stars, 4: 4 stars, 5: 5 stars

}

type RideAddress struct {
	Id            int64  `json:"id" bson:"_id"`
	Name          string `json:"name" bson:"name"`
	ContactNumber string `json:"contact_number" bson:"contact_number"`
	Address       string `json:"address" bson:"address"`
	Landmark      string `json:"landmark" bson:"landmark"`
	City          string `json:"city" bson:"city"`
	State         string `json:"state" bson:"state"`
	Country       string `json:"country" bson:"country"`
	Pincode       string `json:"pincode" bson:"pincode"`

	Latitude  float64 `json:"latitude" bson:"latitude"`
	Longitude float64 `json:"longitude" bson:"longitude"`
}

type Item struct {
	Id              int64   `json:"id" bson:"_id"`
	Name            string  `json:"name" bson:"name"`
	Image           string  `json:"image" bson:"image"`
	SuitableVehicle []int64 `json:"suitable_vehicle" bson:"suitable_vehicle"`
	MinWeight       float64 `json:"min_weight" bson:"min_weight"`
	MaxWeight       float64 `json:"max_weight" bson:"max_weight"`

	Price float64 `json:"price" bson:"price"` // per kg
}

type Vehicle struct {
	Id    int64  `json:"id" bson:"_id"`
	Name  string `json:"name" bson:"name"`
	Image string `json:"image" bson:"image"`

	MinWeight float64 `json:"min_weight" bson:"min_weight"`
	MaxWeight float64 `json:"max_weight" bson:"max_weight"`
	Price     float64 `json:"price" bson:"price"` // per km
}

type RidePayment struct {
}

export interface Origin {
  lat: number;
  lng: number;
  placeId: string;
  formatedAddress: string;
}

export interface Destination {
  lat: number;
  lng: number;
  placeId: string;
  formatedAddress: string;
}

export interface ExpectedDistance {
  text: string;
  value: number;
}

export interface ExpectedTime {
  bookingTime: Date;
  expectedTravelTime: any;
  expectedTravelTimeFormated: string;
  estimatedDepartureTime: Date;
  estimatedArrivalTime: Date;
}

export interface FeedBack {
  userRating: number;
  driverRating: number;
  userComment: string;
  driverComment: string;
}

export interface BookingUserPayment {
  userPaymentStatus: number;
  userPaymentAmount: number;
  userPaymentMode: string;
  userPaymentId: string;
  userPaymentMetaData: string;
  collectedBy: string;
}

export interface BookingDriverPayment {
  driverPaymentStatus: number;
  driverPaymentAmount: number;
  driverPaymentMode: string;
  driverPaymentId: string;
  driverPaymentMetaData: string;
}

export interface BookingPayment {
  userPaymentMode: ReactNode;
  amount: number;
  tax: number;
  total: number;
  bhaadaCharge: number;
  driverCharge: number;
  bookingUserPayment: BookingUserPayment;
  bookingDriverPayment: BookingDriverPayment;
}

export interface User {
  id: string;
  name: string;
  email: string;
  mobile: string;
  age: number;
  gender: string;
  avatar: string;
  password: string;
  created_at: Date;
  updated_at: Date;
  is_driver: boolean;
  is_admin: boolean;
  is_profile_complete: boolean;
  is_active: boolean;
  is_deleted: boolean;
  is_verified: boolean;
  is_email_verified: boolean;
  is_mobile_verified: boolean;
}

export interface Driver {
  id: string;
  name: string;
  email: string;
  mobile: string;
  age: number;
  gender: string;
  avatar: string;
  createdAt: Date;
  updatedAt: Date;
  isActive: boolean;
  isVerified: boolean;
  isDeleted: boolean;
  isEmailVerified: boolean;
  isMobileVerified: boolean;
  drivingLicense: string;
  panCard: string;
  aadharCard: string;
  aadharNumber: string;
  panNumber: string;
  drivingNumber: string;
  model: string;
  vehicalNumber: string;
  vehicalRc: string;
  vehicalInsurance: string;
  fitnessCert: string;
}

export interface Vehicle {
  id: number;
  name: string;
  image: string;
  perKmPrice: number;
  minimumPrice: number;
  category: number;
  weight: string;
  status: number;
  price: number;
}

export interface Booking {
  id: string;
  userId: string;
  driverId: string;
  origin: Origin;
  destination: Destination;
  createdAt: Date;
  updatedAt: Date;
  expectedDistance: ExpectedDistance;
  expectedTime: ExpectedTime;
  vehicleId: number;
  weight: number;
  status: number;
  feedBack: FeedBack;
  bookingPayment: BookingPayment;
  user: User;
  driver: Driver;
  vehicle: Vehicle;
}

export interface PreBooking {
  id: string;
  bookingId: string;
  driverId: string;
  booking: Booking;
}

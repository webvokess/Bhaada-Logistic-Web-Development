package model

import (
	"bhaada-backend/db"
	"time"

	"go.mongodb.org/mongo-driver/bson/primitive"
	"go.mongodb.org/mongo-driver/mongo"
)

type AuthOtp struct {
	Id        primitive.ObjectID `bson:"_id,omitempty" json:"id,omitempty"`
	Otp       string             `json:"otp" bson:"otp"`
	Mobile    string             `json:"mobile" bson:"mobile"`
	Expired   time.Time          `json:"expired" bson:"expired"`
	CreatedAt time.Time          `json:"created_at" bson:"created_at"`
	Status    int                `json:"status" bson:"status"` // 0: active, 1: expired
}

func (m *AuthOtp) IsValid(otp string) bool {

	if m.Status == 1 {

		return false

	}

	if m.Otp != otp {

		return false

	}

	if m.Expired.Before(time.Now()) {

		return false

	}

	return true

}

type AuthRefreshToken struct {
	Id        primitive.ObjectID `json:"id" bson:"_id,omitempty"`
	UserId    primitive.ObjectID `json:"user_id" bson:"user_id"`
	Expired   time.Time          `json:"expired" bson:"expired"`
	CreatedAt time.Time          `json:"created_at" bson:"created_at"`
	Status    int                `json:"status" bson:"status"` // 0: active, 1: expired
}

func (m *AuthRefreshToken) IsValid(userId string) bool {

	if m.Status == 1 {
		return false

	}
	if m.UserId.Hex() != userId {
		return false

	}
	if m.Expired.Before(time.Now()) {

		return false

	}

	return true

}

func AuthOtpCollection() *mongo.Collection {
	return db.GetClient().Collection("auth_otp")
}

func RefreshTokenCollection() *mongo.Collection {
	return db.GetClient().Collection("refresh_tokens")
}

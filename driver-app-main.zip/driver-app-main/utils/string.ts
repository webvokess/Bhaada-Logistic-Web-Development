export const stringToInt = (value: string) => {
  if (value == "") {
    return 0;
  }
  return parseInt(value);
};

import { GET_TOKENS, SET_TOKENS, SIGN_IN } from "./actionTypes";
import * as SecureStore from "expo-secure-store";
import { AnyAction, Reducer } from "@reduxjs/toolkit";
const initialState: Tokens = {
  accessToken: null,
  refreshToken: null,
  expiredIn: null,
};

const authReducer = (
  state: Tokens = initialState,
  action: TokensAction | AnyAction
) => {
  switch (action.type) {
    case SET_TOKENS:
      return {
        ...state,
        ...action.token,
      };

    default:
      return state;
  }
};

export default authReducer;

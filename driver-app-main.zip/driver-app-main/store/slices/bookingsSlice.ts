import { PayloadAction, createSlice } from "@reduxjs/toolkit";

import { RootState } from "../store";

import { Booking } from "../../types/booking";
import { axiosInstance } from "../../utils/axios";

const initialState : BookingState= {
  bookings: [],
}

type BookingState  = {
  bookings: Booking[] | null;
};


export const bookingSlice = createSlice({
  name: "booking",
  initialState,
  reducers: {
    setBooking: (state, action: PayloadAction<Booking[]>) => {
       state.bookings = action.payload;
    },
  },
});

export const { setBooking } = bookingSlice.actions;

export const selectBookings = (state: RootState) => state.booking.bookings;
export const selectBookingById = (state: RootState, id: string) =>
  state.booking.bookings.find((booking) => booking.id === id);
// export const selectBookingByDriverId = (state: RootState, driverId: string) =>
//   state.booking.filter((booking) => booking.driverId === driverId);
// export const selectBookingByIndex = (state: RootState, index: number) =>
//   state.booking[index];

// export const pushBooking = (state: RootState, booking: Booking) => {
//   state.booking.push(booking);
// };

export const refreshBooking = async (state: RootState) => {
 
};

export default bookingSlice.reducer;

/**
 * If you are not familiar with React Navigation, refer to the "Fundamentals" guide:
 * https://reactnavigation.org/docs/getting-started
 *
 */
import { FontAwesome } from "@expo/vector-icons";
import {
  NavigationContainer,
  DefaultTheme,
  DarkTheme,
} from "@react-navigation/native";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import * as React from "react";
import { ColorSchemeName, Pressable } from "react-native";

import LinkingConfiguration from "./LinkingConfiguration";
import * as SecureStore from "expo-secure-store";
import { useDispatch, useSelector } from "react-redux";
import { selectAccessToken, setToken } from "../store/slices/tokens";

import { axiosInstance } from "../utils/axios";
import { selectDriver, setDriver } from "../store/slices/driver";
import WelcomeScreen from "../screens/WelcomeScreen";
import Dashboard from "../screens/Dashboard";
import MenuScreen from "../screens/MenuScreen";
import Profile from "../screens/Profile";
import Edit from "../screens/EditProfile";
import Bookings from "../screens/Bookings";
import UpdateVehicle from "../screens/AddVehicle";
import SignInScreen from "../screens/Login";
import AuthOtpScreen from "../screens/AuthOtp";
import Support from "../screens/Support";
import DriverBookings from "../screens/DriverBookings";
import Settings from "../screens/Settings";
import BookingDetail from "../screens/BookingDetail";
import i18n from "../components/local";
import * as Localization from "expo-localization";
import AddAadharCard from "../screens/Aadhar";
import AddPanCard from "../screens/Pan";
import AddDriverLicence from "../screens/DriverLincence";
export default function Navigation() {
  return (
    <NavigationContainer>
      <RootNavigator />
    </NavigationContainer>
  );
}

/**
 * A root stack navigator is often used for displaying modals on top of all other content.
 * https://reactnavigation.org/docs/modal
 */
const Stack = createNativeStackNavigator();
const AuthContext = React.createContext();
function RootNavigator() {
  const dispatch = useDispatch();

  const token = useSelector(selectAccessToken);

  React.useEffect(() => {
    const bootstrapAsync = async () => {
      const local = await SecureStore.getItemAsync("local");

      if (local) {
        i18n.locale = local;
      } else {
        i18n.locale = Localization.locale;
      }
    };

    bootstrapAsync();
  });

  React.useEffect(() => {
    // Fetch the token from storage then navigate to our appropriate place
    const bootstrapAsync = async () => {
      let tokens: any;

      try {
        tokens = (await SecureStore.getItemAsync("driverToken")) as any;

        tokens = JSON.parse(tokens);

        if (tokens.accessToken && tokens.accessToken !== "") {
          dispatch(
            setToken({
              accessToken: tokens.accessToken,
              refreshToken: tokens.refreshToken,
              expiredIn: tokens.expiredIn,
            })
          );
        }

        const res = await axiosInstance.get(
          `driver/profile/${tokens.driverId}`
        );

        if (res.status == 200) {
          const data: any = res.data.data;

          console.log(data);

          dispatch(setDriver(data));
        }
      } catch (e) {
        console.log(e);
        // Restoring token failed
      }
    };

    bootstrapAsync();
  }, []);

  return (
    <Stack.Navigator
      screenOptions={{
        headerStyle: {
          backgroundColor: "white",
        },

        headerTitleStyle: {
          color: "blue",
        },
      }}
    >
      {token == null ? (
        <>
          <Stack.Screen
            name="Welcome"
            component={WelcomeScreen}
            options={{ headerShown: false }}
          />
          <Stack.Screen name="SignIn" component={SignInScreen} />
          <Stack.Screen name="AuthOtp" component={AuthOtpScreen} />
        </>
      ) : (
        <>
          <Stack.Screen
            name="Dashboard"
            component={Dashboard}
            options={{ headerShown: false }}
          />
          <Stack.Screen
            name="MenuScreen"
            component={MenuScreen}
            options={{ headerShown: false }}
          />
          <Stack.Screen
            name="Profile"
            component={Profile}
            options={{ headerShown: false }}
          />
          <Stack.Screen
            name="Edit"
            component={Edit}
            options={{ headerShown: false }}
          />
          <Stack.Screen
            name="Bookings"
            component={Bookings}
            options={{ headerShown: false }}
          />
          <Stack.Screen
            name="AddVehicle"
            component={UpdateVehicle}
            options={{ headerShown: false }}
          />
          <Stack.Screen
            name="Support"
            component={Support}
            options={{ headerShown: false }}
          />

          <Stack.Screen
            name="DriverBooking"
            component={DriverBookings}
            options={{
              headerShown: false,
            }}
          />
          <Stack.Screen
            name="BookingDetail"
            component={BookingDetail}
            options={{
              headerShown: false,
            }}
          />

          <Stack.Screen
            name="Settings"
            component={Settings}
            options={{ headerShown: false }}
          />

          <Stack.Screen
            name="Aadhar"
            component={AddAadharCard}
            options={{ headerShown: false }}
          />

          <Stack.Screen
            name="Pan"
            component={AddPanCard}
            options={{ headerShown: false }}
          />
          <Stack.Screen
            name="License"
            component={AddDriverLicence}
            options={{ headerShown: false }}
          />
        </>
      )}
    </Stack.Navigator>
  );
}

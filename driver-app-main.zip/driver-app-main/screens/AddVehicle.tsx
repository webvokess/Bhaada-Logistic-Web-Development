import {
  StyleSheet,
  Text,
  View,
  SafeAreaView,
  TouchableOpacity,
  Image,
  TextInput,
  Button,
} from "react-native";
import React, { Dispatch, useState } from "react";
import tw from "tailwind-react-native-classnames";
import truck from "../assets/truck.png";
import arrow from "../assets/arrow.png";
import { useNavigation } from "@react-navigation/native";
import { useDispatch, useSelector } from "react-redux";
import { selectDriver, setDriver } from "../store/slices/driver";
import * as DocumentPicker from "expo-document-picker";
import { axiosInstance } from "../utils/axios";
import { Picker } from "@react-native-picker/picker";
import i18n from "../components/local";

const UpdateVehicle = () => {
  const driver = useSelector(selectDriver);
  const inputs = {
    model: driver.model,
    vehicalNumber: driver.vehicalNumber,
    vehicalRc: driver.vehicalNumber,
    vehicalInsurance: driver.vehicalInsurance,
    fitnessCert: driver.vehicalInsurance,
  };
  const dispatch: Dispatch<any> = useDispatch();
  const [input, setInput] = useState(inputs);
  const changeHandler = (name: string, value: string) => {
    setInput({ ...input, [name]: value });
  };

  const addDocument = async (change: string) => {
    let _document = await DocumentPicker.getDocumentAsync();

    if (_document.type == "cancel") {
      return;
    }

    let localUri = _document.uri;
    let filename = localUri.split("/").pop();

    let match = /\.(\w+)$/.exec(filename);
    let type = match ? `image/${match[1]}` : `image`;

    let formData = new FormData();

    formData.append("file", { uri: localUri, name: filename, type });
    formData.append("folder", "driver");

    console.log(formData);

    try {
      const res = await axiosInstance.post("/upload", formData, {
        headers: {
          "Content-Type": "multipart/form-data",
        },
      });

      if (res.status === 200) {
        const image = "http://cdn.bhaada.co.in" + res.data.pathname;
        changeHandler(change, res.data.pathname);
      }
    } catch (error) {
      console.log(error.response);
    }
  };

  const saveDetail = async () => {
    try {
      console.log(driver);

      const res = await axiosInstance.post(
        `driver/profile/update/${driver.id}`,
        input
      );

      console.log(input);

      if (res.status === 200) {
        dispatch(setDriver(res.data.data));
        navigation.goBack();
      }
    } catch (error) {
      console.log(error);
    }
  };

  const { model, vehicalNumber, vehicalRc, vehicalInsurance, fitnessCert } =
    input;
  const navigation = useNavigation();
  return (
    <SafeAreaView style={[tw`flex-1`, { backgroundColor: "#eef9ff" }]}>
      <View style={tw`flex-row items-center pt-10 px-5`}>
        <TouchableOpacity
          onPress={() => navigation.goBack()}
          style={tw`rounded-full p-2 border-gray-300 border`}
        >
          <Image source={arrow} />
        </TouchableOpacity>
        <Text style={tw`text-2xl font-bold ml-5`}> {i18n.t("back")}   </Text>
      </View>
      <View>
        <View style={tw`flex-row justify-between items-center px-10 mt-3`}>
          <Text
            style={[
              tw`text-xl`,
              { color: "#3E4958", fontFamily: "Mulish_700Bold" },
            ]}
          >
            {i18n.t("addVehicle")}
          </Text>
          <Image
            source={truck}
            style={{ width: 100, height: 60, resizeMode: "contain" }}
          ></Image>
        </View>
        {/* Line */}
        <View style={tw`h-0.5 border-b border-gray-300 mx-10 my-3`} />
      </View>

      <View style={tw`px-10 mt-3`}>
        <Text style={tw`mt-2`}> {i18n.t("vehicleModel")} </Text>
        <Picker
          selectedValue={input.model}
          onValueChange={(itemValue, itemIndex) =>
            changeHandler("model", itemValue)
          }
        >
          <Picker.Item label="Bike Cargo" value="1" />
          <Picker.Item label="DCM Truck" value="2" />
          <Picker.Item label="Pickup" value="3" />
          <Picker.Item label="Mini truck" value="4" />
        </Picker>
      </View>
      <View style={tw`h-0.5 border-b border-gray-300 mx-10 my-3`} />

      <View style={tw`px-10 mt-3`}>
        <Text style={tw`mt-2`}>  {i18n.t("vehicleNumber")}  </Text>
        <TextInput
          style={tw`text-black text-lg `}
          value={input.vehicalNumber}
          onChangeText={(text) => changeHandler("vehicalNumber", text)}
        ></TextInput>
      </View>
      <View style={tw`h-0.5 border-b border-gray-300 mx-10 my-3`} />

      <View style={tw`px-10 mt-3`}>
        <Text style={tw`mt-2`}>{i18n.t("vehicleRcDocument")}  </Text>
        <TouchableOpacity onPress={() => addDocument("vehicalRc")}>
          <View
            style={[
              tw`rounded-2xl justify-center items-center`,
              { backgroundColor: "#3268a8" },
            ]}
          >
            <Text
              style={[
                tw`text-white text-center text-lg`,
                { fontFamily: "Mulish_700Bold" },
              ]}
            >
              {i18n.t("select")} 📑
            </Text>
          </View>
        </TouchableOpacity>
      </View>
      <View style={tw`h-0.5 border-b border-gray-300 mx-10 my-3`} />

      <View style={tw`px-10 mt-3`}>
        <Text style={tw`mt-2`}>{i18n.t("vehicleInsuranceDocument")}    </Text>
        <TouchableOpacity onPress={() => addDocument("vehicalInsurance")}>
          <View
            style={[
              tw`rounded-2xl justify-center items-center`,
              { backgroundColor: "#3268a8" },
            ]}
          >
            <Text
              style={[
                tw`text-white text-center text-lg`,
                { fontFamily: "Mulish_700Bold" },
              ]}
            >
              {i18n.t("select")} 📑
            </Text>
          </View>
        </TouchableOpacity>
      </View>
      <View style={tw`h-0.5 border-b border-gray-300 mx-10 my-3`} />

      <View style={tw`px-10 mt-3`}>
        <Text style={tw`mt-2`}>{i18n.t("vehicleFitnessCerts")}  </Text>
        <TouchableOpacity onPress={() => addDocument("fitnessCert")}>
          <View
            style={[
              tw`rounded-2xl justify-center items-center`,
              { backgroundColor: "#3268a8" },
            ]}
          >
            <Text
              style={[
                tw`text-white text-center text-lg`,
                { fontFamily: "Mulish_700Bold" },
              ]}
            >
               {i18n.t("select")} 📑
            </Text>
          </View>
        </TouchableOpacity>
      </View>
      <View style={tw`h-0.5 border-b border-gray-300 mx-10 my-3`} />

      <TouchableOpacity onPress={saveDetail} style={tw`pt-10`}>
        <View
          style={[
            tw`h-14 w-11/12 mx-auto rounded-2xl justify-center items-center`,
            { backgroundColor: "#06ab48" },
          ]}
        >
          <Text
            style={[
              tw`text-white text-center text-lg`,
              { fontFamily: "Mulish_700Bold" },
            ]}
          >
            {i18n.t("saveDetails")}
          </Text>
        </View>
      </TouchableOpacity>
    </SafeAreaView>
  );
};

export default UpdateVehicle;

const styles = StyleSheet.create({});
 

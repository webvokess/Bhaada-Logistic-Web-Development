package db

import (
	"bhaada-backend/config"
	"bhaada-backend/logger"

	"context"
	"go.mongodb.org/mongo-driver/mongo"
	"go.mongodb.org/mongo-driver/mongo/options"
	"sync"
)

var mongoDb *mongo.Database
var once sync.Once

func Init() {
	once.Do(func() {
		cfg := config.Get()

		client, err := mongo.Connect(context.TODO(), options.Client().ApplyURI(cfg.MongoUrl))
		if err != nil {
			panic(err)
		}

		err = client.Ping(context.TODO(), nil)
		if err != nil {
			panic(err)
		}

		mongoDb = client.Database(cfg.MongoDb)

		logger.Client().Info("Connected to MongoDB")

	})
}

func GetClient() *mongo.Database {
	return mongoDb
}

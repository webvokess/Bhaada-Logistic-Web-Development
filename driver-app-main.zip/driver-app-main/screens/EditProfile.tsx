import {
  StyleSheet,
  Text,
  View,
  SafeAreaView,
  TouchableOpacity,
  Image,
  TextInput,
  ScrollView,
} from "react-native";
import React, { Dispatch, useState } from "react";
import tw from "tailwind-react-native-classnames";
import person from "../assets/person.png";
import arrow from "../assets/arrow.png";
import { useNavigation } from "@react-navigation/native";
import {
  selectDriver,
  selectDriverAvatar,
  setDriver,
} from "../store/slices/driver";
import { useDispatch, useSelector } from "react-redux";
import { axiosInstance } from "../utils/axios";
import { stringToInt } from "../utils/string";
import { AntDesign } from "@expo/vector-icons";

import * as ImagePicker from "expo-image-picker";
import i18n from "../components/local";
import { Picker } from "@react-native-picker/picker";

const Edit = () => {
  const driver = useSelector(selectDriver);
  const inputs = {
    name: driver.name,
    email: driver.email,
    age: driver.age,
    gender: driver.gender,
    aadharNumber: driver.aadharNumber,
    panNumber: driver.panNumber,
    image: driver.avatar,
  };
  const [input, setInput] = useState(inputs);
  const changeHandler = (name: string, value: string) => {
    setInput({ ...input, [name]: value });
  };
  const navigation = useNavigation();
  const dispatch: Dispatch<any> = useDispatch();
  const [image, setImage] = useState(useSelector(selectDriverAvatar));
  const addImage = async () => {
    let _image = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: true,
      aspect: [4, 3],
      quality: 1,
    });

    if (_image.cancelled) {
      return;
    }

    let localUri = _image.uri;
    let filename = localUri.split("/").pop();

    let match = /\.(\w+)$/.exec(filename);
    let type = match ? `image/${match[1]}` : `image`;

    let formData = new FormData();

    formData.append("file", { uri: localUri, name: filename, type });
    formData.append("folder", "driver");

    console.log(formData);

    try {
      const res = await axiosInstance.post("/upload", formData, {
        headers: {
          "Content-Type": "multipart/form-data",
        },
      });

      if (res.status === 200) {
        const image = "http://cdn.bhaada.co.in" + res.data.pathname;
        setImage(image);
        changeHandler("avatar", res.data.pathname);
      }
    } catch (error) {
      console.log(error.response);
    }
  };

  const saveDetail = async () => {
    try {
      console.log(input);
      console.log(driver.id);

      const res = await axiosInstance.post(
        `driver/profile/update/${driver.id}`,
        input
      );

      console.log(input);

      if (res.status === 200) {
        alert("Successfully updated");

        console.log(res.data);

        dispatch(setDriver(res.data.data));

        if (driver.aadharCard == "") {
          navigation.navigate("Aadhar");
        } else if (driver.panCard == "") {
          navigation.navigate("Pan");
        } else if (driver.drivingNumber == "") {
          navigation.navigate("License");
        } else if (driver.vehicalNumber == "") {
          navigation.navigate("AddVehicle");
        } else {
          navigation.navigate("Dashboard");
        }
      }
    } catch (error) {
      console.log(error);
    }
  };
  return (
    <SafeAreaView style={[tw`flex-1`, { backgroundColor: "#eef9ff" }]}>
      <ScrollView>
        <View style={tw`flex-row items-center pt-10 px-5`}>
          <TouchableOpacity
            onPress={() => navigation.goBack()}
            style={tw`rounded-full p-2 border-gray-300 border`}
          >
            <Image source={arrow} />
          </TouchableOpacity>
          <Text style={tw`text-2xl font-bold ml-5`}> Back</Text>
        </View>
        <View>
          <View style={tw`flex-row justify-between items-center px-10 mt-3`}>
            <Text
              style={[
                tw`text-xl`,
                { color: "#3E4958", fontFamily: "Mulish_700Bold" },
              ]}
            >
              Edit your Profile
            </Text>

            <View style={imageUploaderStyles.container}>
              {image && (
                <Image
                  source={{ uri: image }}
                  style={{ width: 100, height: 60, resizeMode: "contain" }}
                />
              )}

              <View style={imageUploaderStyles.uploadBtnContainer}>
                <TouchableOpacity
                  onPress={addImage}
                  style={imageUploaderStyles.uploadBtn}
                >
                  <Text>{image ? "Edit" : "Upload"} Image</Text>
                  <AntDesign name="camera" size={20} color="black" />
                </TouchableOpacity>
              </View>
            </View>
          </View>
          {/* Line */}
          <View style={tw`h-0.5 border-b border-gray-300 mx-10 my-3`} />
        </View>

        <View style={tw`px-10 mt-3`}>
          <Text style={tw`mt-2`}> {i18n.t("name")} </Text>
          <TextInput
            style={tw`text-black text-lg `}
            value={input.name}
            onChangeText={(text) => changeHandler("name", text)}
          ></TextInput>
        </View>
        <View style={tw`h-0.5 border-b border-gray-300 mx-10 my-3`} />

        <View style={tw`px-10 mt-3`}>
          <Text style={tw`mt-2`}> {i18n.t("email")} </Text>
          <TextInput
            style={tw`text-black text-lg `}
            value={input.email}
            onChangeText={(text) => changeHandler("email", text)}
          ></TextInput>
        </View>
        <View style={tw`h-0.5 border-b border-gray-300 mx-10 my-3`} />

        <View style={tw`px-10 mt-3`}>
          <Text style={tw`mt-2`}>{i18n.t("age")}</Text>
          <TextInput
            style={tw`text-black text-lg `}
            value={input.age.toString()}
            onChangeText={(text) => changeHandler("age", stringToInt(text))}
          ></TextInput>
        </View>
        <View style={tw`h-0.5 border-b border-gray-300 mx-10 my-3`} />

        <View style={tw`px-10 mt-3`}>
          <Text style={tw`mt-2`}> {i18n.t("gender")} </Text>
          <Picker
            selectedValue={input.gender}
            onValueChange={(itemValue, itemIndex) =>
              changeHandler("gennder", itemValue)
            }
          >
            <Picker.Item label="Male" value="Male" />
            <Picker.Item label="Female" value="Female" />
            <Picker.Item label="Other" value="Other" />
          </Picker>
        </View>
        <View style={tw`h-0.5 border-b border-gray-300 mx-10 my-3`} />

        <TouchableOpacity onPress={saveDetail} style={tw`py-5`}>
          <View
            style={[
              tw`h-14 w-11/12 mx-auto rounded-2xl justify-center items-center`,
              { backgroundColor: "blue" },
            ]}
          >
            <Text
              style={[
                tw`text-white text-center text-lg`,
                { fontFamily: "Mulish_700Bold" },
              ]}
            >
              Save Details
            </Text>
          </View>
        </TouchableOpacity>
      </ScrollView>
    </SafeAreaView>
  );
};

const imageUploaderStyles = StyleSheet.create({
  container: {
    elevation: 2,
    height: 100,
    width: 100,
    backgroundColor: "#efefef",
    position: "relative",
    borderRadius: 999,
    overflow: "hidden",
  },
  uploadBtnContainer: {
    opacity: 0.7,
    position: "absolute",
    right: 0,
    bottom: 0,
    backgroundColor: "lightgrey",
    width: 100,
    height: 60,
  },
  uploadBtn: {
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
  },
});
export default Edit;

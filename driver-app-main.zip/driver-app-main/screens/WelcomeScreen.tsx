import {
  StyleSheet,
  Text,
  View,
  SafeAreaView,
  TouchableOpacity,
} from "react-native";
import React from "react";
import tw from "tailwind-react-native-classnames";
import Swiper from "react-native-swiper";
import Card from "../components/Card";

const WelcomeScreen = ({ navigation }) => {
  return (
    <SafeAreaView style={[tw`flex-1`, { backgroundColor: "#7185f0" }]}>
      <View style={tw`items-center mt-12`}>
        <Text
          style={[
            tw`text-xl`,
            { fontFamily: "Mulish_700Bold", color: "#3E4958" },
          ]}
        >
          WELCOME
        </Text>
        <Text
          style={[
            tw`text-xl`,
            { fontFamily: "Mulish_700Bold", color: "#3E4958" },
          ]}
        >
          TO
        </Text>
        <Text
          style={[
            tw`text-white text-2xl mt-2`,
            { fontFamily: "Mulish_700Bold" },
          ]}
        >
          BHAADA DRIVER APP
        </Text>
      </View>
      <Swiper
        loop={true}
        showsPagination={false}
        autoplay
        style={[tw`pt-10`, { height: 400 }]}
      >
        <Card />
        <Card />
        <Card />
      </Swiper>
      <TouchableOpacity
        onPress={() => navigation.navigate("SignIn")}
        style={[
          tw`rounded-2xl absolute bottom-28 left-8 items-center justify-center`,
          { backgroundColor: "#3E0AD2", width: 330, height: 60 },
        ]}
      >
        <Text
          style={[tw`text-white text-xl`, { fontFamily: "Mulish_700Bold" }]}
        >
          Sign Up
        </Text>
      </TouchableOpacity>
      <TouchableOpacity
        style={[
          tw`justify-center items-center py-5`,
          { backgroundColor: "#D2FFF4" },
        ]}
        onPress={() => navigation.navigate("SignIn")}
      >
        <Text style={[tw`text-base`, { fontFamily: "Mulish_700Bold" }]}>
          Already have an account? Login Here.
        </Text>
      </TouchableOpacity>
    </SafeAreaView>
  );
};

export default WelcomeScreen;

const styles = StyleSheet.create({});

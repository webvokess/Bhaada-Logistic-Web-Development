package dto

import "errors"

type CreateOtpRequest struct {
	Mobile string `json:"mobile"`
}

type VerifyOtpRequest struct {
	Otp    string `json:"otp"`
	Id     string `json:"id"`
	Mobile string `json:"mobile"`
}

func (req *VerifyOtpRequest) Validate() error {
	if req.Otp == "" {
		return errors.New("otp is required")
	}
	if req.Id == "" {
		return errors.New("id is required")
	}
	if req.Mobile == "" {
		return errors.New("mobile is required")
	}
	return nil
}

type RefreshTokenRequest struct {
	Token string `json:"token"`
}

package utils

import (
	"time"

	"github.com/dgrijalva/jwt-go"
)

type Claims struct {
	ID string `json:"id"`
	jwt.StandardClaims
}

var AccessTokenExpired = time.Hour * 24 * 7
var RefreshTokenExpired = time.Hour * 24 * 30

// Create the JWT key used to create the signature
var jwtKey = []byte("my_secret_key")

func CreateJWT(id string, expiredIn time.Duration) (string, error) {

	expirationTime := time.Now().Add(expiredIn)

	claims := &Claims{
		ID: id,
		StandardClaims: jwt.StandardClaims{

			ExpiresAt: expirationTime.Unix(),
		},
	}

	token := jwt.NewWithClaims(jwt.SigningMethodHS256, claims)

	tokenString, err := token.SignedString(jwtKey)

	if err != nil {
		return "", err
	}

	return tokenString, nil
}

func VerifyJWT(tokenString string) (*Claims, error) {

	token, err := jwt.ParseWithClaims(tokenString, &Claims{}, func(token *jwt.Token) (interface{}, error) {
		return jwtKey, nil
	})

	if err != nil {
		return nil, err
	}

	if claims, ok := token.Claims.(*Claims); ok && token.Valid {
		return claims, nil
	}

	return nil, err
}

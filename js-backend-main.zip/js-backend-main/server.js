require("dotenv").config();
const express = require("express");
const app = express();
const map = require("@googlemaps/google-maps-services-js");
const axios = require("axios");
const turf = require("@turf/turf");
var polyUtil = require("@googlemaps/polyline-codec");
require("copy-paste");
app.use(express.json());

// looging middleware with timestamp and request url

app.use((req, res, next) => {
  console.log(`${new Date().toString()} => ${req.originalUrl}`);
  next();
});


var NodeGeocoder = require("node-geocoder");

const port = 8005;

async function GetGeoCode(lat, lon) {
  var options = {
    provider: "google",
    httpAdapter: "https", // Default
    apiKey: "AIzaSyDVqHbi_0Cqz23epmS9UjK6oHgQR40-3TA", // for Mapquest, OpenCage, Google Premier
    formatter: "json", // 'gpx', 'string', ...
  };

  var geocoder = NodeGeocoder(options);

  const res = await geocoder.reverse({ lat: lat, lon: lon });
  return {
    city: res[0].city,
    state: res[0].administrativeLevels.level1long,
    country: res[0].country,
    pincode: res[0].zipcode,
    shortFormatedAddress:
      res[0].city +
      ", " +
      res[0].administrativeLevels.level1long +
      ", " +
      res[0].country,
    formattedAddress: res[0].formattedAddress,
    googlePlaceId: res[0].googlePlaceId,

    metaData: res[0],
  };
}

async function GetPolygonOfCity(city) {
  // get request to https://nominatim.openstreetmap.org/search.php?q=kanpur&format=jsonv2&polygon_geojson=1
  // get the polygon from the response

  const polygon = await axios.get(
    `https://nominatim.openstreetmap.org/search.php?q=${city}&format=jsonv2&polygon_geojson=1`
  );

  polygon.data.map((item) => {
    if (item.geojson.type === "Polygon") {
      return item.geojson.coordinates;
    }
  });

  return polygon.data[0].geojson.coordinates;
}

const AzureBlobURL = "https://bhaada-cdn.azureedge.net/bhaada";

const vehicles = [
  //   {
  //     id: 1,
  //     name: "Packers and Movers",
  //     image: "http://34.149.69.167/bhaada/vehicle/packers_and_movers.jpeg",
  //     perKmPrice: 10,
  //     minimumPrice: 150,
  //     weight: "50 Kg - 100 Kg",
  //   },
  {
    id: 2,
    name: "Bike Cargo",
    image:  `${AzureBlobURL}/vehicle/mopad.png`,
    perKmPrice: 10,
    minimumPrice: 150,
    weight: "50 Kg - 100 Kg",
  },
  {
    id: 3,
    name: "E-Rikshaw",
    image:  `${AzureBlobURL}/vehicle/E_RIKSHAW.png`,
    perKmPrice: 10,
    minimumPrice: 150,
    weight: "50 Kg - 100 Kg",
  },
  {
    id: 4,
    name: "DCM Truck",
    image:  `${AzureBlobURL}/vehicle/Ttruck.png`,
    perKmPrice: 15,
    minimumPrice: 200,
    weight: "1000kg - 4ton",
  },
  {
    id: 5,
    name: "Pickup",
    image:  `${AzureBlobURL}/vehicle/pickup.png`,
    perKmPrice: 15,
    minimumPrice: 200,
    weight: "1000kg - 4ton",
  },
  {
    id: 6,
    name: "Mini truck",
    image: `${AzureBlobURL}/vehicle/MINITRUCK.png`,
    perKmPrice: 15,
    minimumPrice: 200,
    weight: "1000kg - 4ton",
  },
];

async function GetInterCityPricing(origin, destination) {
  const interCityVehicles = {
    "Rath, Uttar Pradesh, India-Hamirpur, Himachal Pradesh, India": [
      {
        id: 4,
        price: 200,
      },
      {
        id: 5,
        price: 300,
      },
      {
        id: 6,
        price: 400,
      },
    ],
    "Kanpur, Uttar Pradesh, India-Meerut, Uttar Pradesh, India": [
      {
        id: 4,
        price: 200,
      },
      {
        id: 5,
        price: 300,
      },
      {
        id: 6,
        price: 400,
      },
    ],
  };

  return interCityVehicles;
}

async function GetVehicleDetail(id) {
  const vehicle = vehicles.filter((vehicle) => vehicle.id === id);
  return vehicle[0];
}

async function GetIntraCityPricing(distance) {
  const intracityVehicle = vehicles.map((vehicle) => {
    price = distance/1000 * vehicle.perKmPrice;
    if (price < vehicle.minimumPrice) {
      price = vehicle.minimumPrice;
    }

    return {
      ...vehicle,
      price,
    };
  });

  return intracityVehicle;
}

function decodePath(encodedPath) {
  let len = encodedPath.length || 0;
  let path = new Array(Math.floor(encodedPath.length / 2));
  let index = 0;
  let lat = 0;
  let lng = 0;
  let pointIndex;
  for (pointIndex = 0; index < len; ++pointIndex) {
    let result = 1;
    let shift = 0;
    let b;
    do {
      b = encodedPath.charCodeAt(index++) - 63 - 1;
      result += b << shift;
      shift += 5;
    } while (b >= 0x1f);
    lat += result & 1 ? ~(result >> 1) : result >> 1;
    result = 1;
    shift = 0;
    do {
      b = encodedPath.charCodeAt(index++) - 63 - 1;
      result += b << shift;
      shift += 5;
    } while (b >= 0x1f);
    lng += result & 1 ? ~(result >> 1) : result >> 1;
    path[pointIndex] = { lat: lat * 1e-5, lng: lng * 1e-5 };
  }
  path.length = pointIndex;
  return path;
}

async function GetDistanceMatrix(origin, destination) {
  const distanceMatrix = await axios.get(
    `https://maps.googleapis.com/maps/api/distancematrix/json?units=metric&origins=${origin.latitude},${origin.longitude}&destinations=${destination.latitude},${destination.longitude}&key=${process.env.GOOGLE_MAPS_API_KEY}`
  );

  return distanceMatrix.data;
}

app.post("/get/fare", async (req, res) => {
  try {
    const { origin, destination, vehicle, detail } = req.body; // origin and destination plcace id

    const client = new map.Client({});

    const [originDetail, destinationDetail, distanceMatrix] = await Promise.all(
      [
        GetGeoCode(origin.latitude, origin.longitude),
        GetGeoCode(destination.latitude, destination.longitude),
        GetDistanceMatrix(origin, destination),
      ]
    );

    const originFormattedAddress = originDetail.shortFormatedAddress;
    const destinationFormattedAddress = destinationDetail.shortFormatedAddress;
    const distance = distanceMatrix.rows[0].elements[0].distance;

    if (originFormattedAddress === destinationFormattedAddress) {
      const intracityVehicle = await GetIntraCityPricing(distance.value);

      if (vehicle == undefined && detail == undefined) {
        return res.send({
          status: "success",
          data: {
            vehicles: intracityVehicle,
            distance: distance,
            duration: distanceMatrix.rows[0].elements[0].duration,
          },
        });
      }

      res.send({
        status: "success",
        data: {
          vehicles: intracityVehicle.filter((v) => v.id == vehicle),
          origin: originDetail,
          destination: destinationDetail,
          distanceMatrix: distanceMatrix.rows[0].elements[0],
          distance: distance,
          duration: distanceMatrix.rows[0].elements[0].duration,
          type: "intra",
        },
      });
    }

    const [originCityPolygon, destinationCityPolygon] = await Promise.all([
      GetPolygonOfCity(originFormattedAddress),
      GetPolygonOfCity(destinationFormattedAddress),
    ]);

    const polyline = await axios.get(
      `https://maps.googleapis.com/maps/api/directions/json?origin=${origin.latitude},${origin.longitude}&destination=${destination.latitude},${destination.longitude}&key=${process.env.GOOGLE_MAPS_API_KEY}`
    );

    const polylinePoints = polyline.data.routes[0].overview_polyline.points;

    const decodedPolyline = decodePath(polylinePoints);

    const originIntersect = turf.lineIntersect(
      turf.lineString(decodedPolyline.map((point) => [point.lng, point.lat])),
      turf.polygon(originCityPolygon)
    );

    const destinationIntersect = turf.lineIntersect(
      turf.lineString(decodedPolyline.map((point) => [point.lng, point.lat])),
      turf.polygon(destinationCityPolygon)
    );

    const [
      originToOriginIntersectionDistanceMatrix,
      destinationIntersectionToDestinationDistanceMatrix,
    ] = await Promise.all([
      GetDistanceMatrix(origin, {
        latitude: originIntersect.features[0].geometry.coordinates[1],
        longitude: originIntersect.features[0].geometry.coordinates[0],
      }),
      GetDistanceMatrix(
        {
          latitude: destinationIntersect.features[0].geometry.coordinates[1],
          longitude: destinationIntersect.features[0].geometry.coordinates[0],
        },
        destination
      ),
    ]);

    const originToOriginIntersectionDistance =
      originToOriginIntersectionDistanceMatrix.rows[0].elements[0].distance;

    const destinationIntersectionToDestinationDistance =
      destinationIntersectionToDestinationDistanceMatrix.rows[0].elements[0]
        .distance;

    // CALCULATE PRICE

    const originToDestination = `${originFormattedAddress}-${destinationFormattedAddress}`;
    let interCityvehicles = await GetInterCityPricing(
      originToDestination,
      distance
    );
    if (originToDestination in interCityvehicles) {
      interCityvehicles = interCityvehicles[originToDestination];
    } else if (
      originToDestination.split("-").reverse().join("-") in interCityvehicles
    ) {
      originToDestination = `${destinationFormattedAddress}-${originFormattedAddress}`;
      interCityvehicles = interCityvehicles[originToDestination];
    } else {
      res.send({
        status: "error",
        message: "No vehicle available for this route",
      });
    }

    const intercityVehicles = [];
    for (let v of interCityvehicles) {
      const vehicle_new = await GetVehicleDetail(v.id);
      const freeIntreCityDistance = 10000; // 10 km
      let price =
        (originToOriginIntersectionDistance.value > freeIntreCityDistance
          ? ((originToOriginIntersectionDistance.value - 10000) / 1000) *
            vehicle_new.perKmPrice
          : 0) +
        v.price +
        (destinationIntersectionToDestinationDistance.value >
        freeIntreCityDistance
          ? ((destinationIntersectionToDestinationDistance.value - 10000) /
              1000) *
            vehicle_new.perKmPrice
          : 0);

      vehicle_new.price = price;
      intercityVehicles.push(vehicle_new);
    }

    if (vehicle == undefined && detail == undefined) {
      return res.send({
        status: "success",
        data: {
          vehicles: intercityVehicles,
          distance: distance,
          duration: distanceMatrix.rows[0].elements[0].duration,
        },
      });
    }

    res.send({
      status: "success",
      data: {
        vehicles: intercityVehicles.filter((v) => v.id == vehicle),
        origin: originDetail,
        destination: destinationDetail,
        type: "intercity",
        distance: distance,
        duration: distanceMatrix.rows[0].elements[0].duration.value,

        originToDestination: {
          origin: originDetail,
          destination: destinationDetail,
          distance: distance,
          duration: distanceMatrix.rows[0].elements[0].duration.value,
          // polyline: polyline.data.routes[0].overview_polyline.points,
        },

        // originCityPolygon: originCityPolygon,
        // destinationCityPolygon: destinationCityPolygon,
        originIntersect: originIntersect,
        destinationIntersect: destinationIntersect,
        originToOriginIntersection: {
          origin: {
            latitude: originDetail.latitude,
            longitude: originDetail.longitude,
            formattedAddress:  originDetail.formattedAddress,
          },
          destination: {
            latitude: originIntersect.features[0].geometry.coordinates[1],
            longitude: originIntersect.features[0].geometry.coordinates[0],
            formattedAddress: originIntersect.features[0].properties.name,
          },
          distance: originToOriginIntersectionDistance,
          duration:
            originToOriginIntersectionDistanceMatrix.rows[0].elements[0]
              .duration.value,
          // polyline: polyline.data.routes[0].overview_polyline.points,
        },

        destinationIntersectionToDestination: {
          origin: {
            latitude: destinationIntersect.features[0].geometry.coordinates[1],
            longitude: destinationIntersect.features[0].geometry.coordinates[0],
            formattedAddress: destinationIntersect.features[0].properties.name,
          },
          destination: {
            latitude: destinationDetail.latitude,
            longitude: destinationDetail.longitude,
            formattedAddress: destinationDetail.formattedAddress,
          },
          distance: destinationIntersectionToDestinationDistance,
          duration:
            destinationIntersectionToDestinationDistanceMatrix.rows[0]
              .elements[0].duration.value,
          // polyline: polyline.data.routes[0].overview_polyline.points,
        },
      },
    });
  } catch (error) {
    console.log(error);
    res.send({
      status: "error",
      message: "Something went wrong",
    });
  }
});



app.listen(port, () => {
  console.log(`app listening at http://localhost:${port}`);
});

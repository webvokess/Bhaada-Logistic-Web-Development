export const GOOGLE_MAPS_API_KEY = "AIzaSyB8XoshW5wrjfjYf7Qv1PvYwfEpCZ6Hkpw";

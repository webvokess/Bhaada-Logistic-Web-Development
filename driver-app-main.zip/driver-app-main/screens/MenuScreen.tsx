import {
  StyleSheet,
  Text,
  View,
  SafeAreaView,
  TouchableOpacity,
  Image,
} from "react-native";
import React from "react";
import tw from "tailwind-react-native-classnames";
import arrow from "../assets/arrow.png";
import { useNavigation } from "@react-navigation/native";
import { useDispatch, useSelector } from "react-redux";
import { Dispatch } from "redux";
import { setToken } from "../store/slices/tokens";
import * as SecureStore from "expo-secure-store";
import { selectDriver } from "../store/slices/driver";
import i18n from "../components/local";

const MenuScreen = () => {
  const navigation = useNavigation();
  const dispatch: Dispatch<any> = useDispatch();
  const user = useSelector(selectDriver);
  return (
    <SafeAreaView>
      <View style={tw`flex-row items-center py-5 px-7 bg-white`} elevation={5}>
        <TouchableOpacity
          style={tw`rounded-full p-2 border-gray-300 border`}
          onPress={() => navigation.goBack()}
        >
          <Image source={arrow} />
        </TouchableOpacity>
        <Text style={[tw`ml-5 text-xl`, { fontFamily: "Mulish_700Bold" }]}>
          {i18n.t("profile")}
        </Text>
      </View>
      <Text
        style={[
          tw`p-5 text-lg text-gray-700`,
          { fontFamily: "Mulish_400Regular" },
        ]}
      >
        {user.name}
      </Text>
      <TouchableOpacity onPress={() => navigation.navigate("Bookings")}>
        <Text
          style={[tw`p-3 px-14 text-base`, { fontFamily: "Mulish_700Bold" }]}
        >
          {i18n.t("bookings")}
        </Text>
      </TouchableOpacity>
      <TouchableOpacity onPress={() => navigation.navigate("DriverBooking")}>
        <Text
          style={[tw`p-3 px-14 text-base`, { fontFamily: "Mulish_700Bold" }]}
        >
          {i18n.t("bookings")}
        </Text>
      </TouchableOpacity>
      <View style={tw`h-0.5 border-b border-gray-300 mx-10 my-3`} />
      <TouchableOpacity onPress={() => navigation.navigate("Profile")}>
        <Text
          style={[tw`p-3 px-14 text-base`, { fontFamily: "Mulish_700Bold" }]}
        >
          {i18n.t("profile")}
        </Text>
      </TouchableOpacity>
      <View style={tw`h-0.5 border-b border-gray-300 mx-10 my-3`} />
      <TouchableOpacity onPress={() => navigation.navigate("Support")}>
        <Text
          style={[tw`p-3 px-14 text-base`, { fontFamily: "Mulish_700Bold" }]}
        >
          {i18n.t("support")}
        </Text>
      </TouchableOpacity>
      <View style={tw`h-0.5 border-b border-gray-300 mx-10 my-3`} />
      <TouchableOpacity onPress={() => navigation.navigate("Settings")}>
        <Text
          style={[tw`p-3 px-14 text-base`, { fontFamily: "Mulish_700Bold" }]}
        >
          {i18n.t("settings")}
        </Text>
      </TouchableOpacity>
      <TouchableOpacity
        style={[
          tw`justify-center bg-blue-600 items-center mx-auto mt-10 rounded-3xl`,
          { width: 330, height: 60 },
        ]}
        onPress={async ({}) => {
          await SecureStore.deleteItemAsync("driverToken");
          dispatch(
            setToken({
              accessToken: null,
              refreshToken: null,
              expiredIn: null,
            })
          );
        }}
      >
        <Text
          style={[tw`text-white text-lg`, { fontFamily: "Mulish_600SemiBold" }]}
        >
          {i18n.t("logout")}
        </Text>
      </TouchableOpacity>
    </SafeAreaView>
  );
};

export default MenuScreen;

const styles = StyleSheet.create({});

import { PayloadAction, createSlice } from "@reduxjs/toolkit";
import { CDN_URL } from "../../constant";

import { RootState } from "../store";

const initialState: Driver = {
  id: "",
  name: "",
  email: "",
  mobile: "",
  age: 0,
  gender: "",
  avatar: "",
  createdAt: undefined,
  updatedAt: undefined,
  isActive: false,
  isVerified: false,
  isDeleted: false,
  isEmailVerified: false,
  isMobileVerified: false,
  drivingLicense: "",
  panCard: "",
  aadharCard: "",
  aadharNumber: "",
  panNumber: "",
  drivingNumber: "",
  model: "",
  vehicalNumber: "",
  vehicalRc: "",
  vehicalInsurance: "",
  fitnessCert: "",
};

export const driverSlice = createSlice({
  name: "driver",
  initialState,
  reducers: {
    setDriver: (state, action: PayloadAction<Driver>) => {
      return {
        ...state,
        ...action.payload,
      };
    },
  },
});

export const { setDriver } = driverSlice.actions;

export const selectDriver = (state: RootState) => state.driver;
export const selectDriverId = (state: RootState) => state.driver.id;
export const selectDriverAvatar = (state: RootState) =>
  state.driver.avatar !== "" ? `${CDN_URL}${state.driver.avatar}` : null;


  export const selectAaadharCard = (state: RootState) =>
  state.driver.aadharCard !== "" ? `${CDN_URL}${state.driver.aadharCard}` : null;

  export const selectPanCard = (state: RootState) =>
  state.driver.panCard !== "" ? `${CDN_URL}${state.driver.panCard}` : null;

  export const selectDrivingLicense = (state: RootState) =>
  state.driver.drivingLicense !== "" ? `${CDN_URL}${state.driver.drivingLicense}` : null;

export default driverSlice.reducer;

import {
    SafeAreaView,
    ScrollView,
    StyleSheet,
    Text,
    TouchableOpacity,
    View,
  } from "react-native";
  import React, { useEffect, useState } from "react";
  import tw from "tailwind-react-native-classnames";
  import { Icon } from "react-native-elements";
  import InfoCard from "../components/InfoCard";
  import bike from "../assets/images/bicycle.png";
  import car from "../assets/images/car.png";
  import { useNavigation } from "@react-navigation/native";
  import {
    refreshBooking,
    selectBookings,
    setBooking,
  } from "../store/slices/bookingsSlice";
  import { useDispatch } from "react-redux";
  import { axiosInstance } from "../utils/axios";
  import { useSelector } from "react-redux";
  import { FlatList, NativeBaseProvider } from "native-base";
  import { Booking } from "../types/booking";
import { selectDriverId } from "../store/slices/driver";
import i18n from "../components/local";
  
  const DriverBookings = () => {
    const [cancel, isCancel] = useState(false);
    const navigation = useNavigation();
    const dispatch = useDispatch();
    const driverID = useSelector(selectDriverId);
  
    const bookings = useSelector(selectBookings);
  
    const FetchRides = async () => {
      const res = await axiosInstance.get(`/bookings?driverID=${driverID}`);
  
      if (res.status === 200) {
        console.log(res.data);
  
        const data: Booking[] = res.data.data;
        dispatch(setBooking(data));
      }
  
      console.log(res);
      
    };
  
    useEffect(() => {
      FetchRides();
    }, []);
  
    return (
      <NativeBaseProvider>
        <SafeAreaView style={tw`flex-1 bg-blue-200`}>
          <ScrollView>
            <View style={tw`flex-row pt-10 bg-white  pb-5 items-center px-5`}>
              <TouchableOpacity onPress={() => navigation.goBack()}>
                <Icon name="arrow-back-outline" type="ionicon" />
              </TouchableOpacity>
              <Text style={tw`ml-5 text-lg font-semibold`}> {i18n.t("driverbooking")} </Text>
            </View>
  
            {bookings &&
              bookings.length > 0 &&
              bookings.map((booking) => (
                <TouchableOpacity
                  onPress={() => {
                    navigation.navigate("BookingDetail", {
                      data: booking,
                      refresh: true,
                      id: booking.id,
                    });
                  }}
                >
                  <InfoCard
                    vehicle={booking.vehicle.name}
                    vehicleNumber={"123456"}
                    image={booking.vehicle.image}
                    rideTime={"Mon, May 23, 04:25 AM"}
                    from={booking.origin.formatedAddress}
                    to={booking.destination.formatedAddress}
                    cancel={cancel}
                  />
                </TouchableOpacity>
              ))}
          </ScrollView>
        </SafeAreaView>
      </NativeBaseProvider>
    );
  };
  
  export default DriverBookings;
  
  const styles = StyleSheet.create({});
  
export const SIGN_IN = "SIGN_IN";
export const SIGN_OUT = "SIGN_OUT";
export const SET_TOKENS = "SET_TOKENS";
export const SET_USER = "SET_USER";
export const GET_TOKENS = "GET_TOKENS";

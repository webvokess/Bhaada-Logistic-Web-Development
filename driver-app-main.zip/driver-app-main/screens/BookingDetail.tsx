import {
  StyleSheet,
  Text,
  View,
  Image,
  TouchableOpacity,
  SafeAreaView,
  ScrollView,
  RefreshControl,
  TextInput,
  Modal,
} from "react-native";
import React, { useEffect, useState } from "react";
import tw from "tailwind-react-native-classnames";
import { useSelector } from "react-redux";
import { selectBookingById } from "../store/slices/bookingsSlice";
import { Booking } from "../types/booking";
import format from "date-fns/format";
import { CDN_URL } from "../constant";
import { useNavigation, useRoute } from "@react-navigation/native";
import { axiosInstance } from "../utils/axios";
import Map1 from "../components/Map1";

import accepted from "../assets/ACCEPTED.png";
import booking from "../assets/BOOKING.png";
import cancelled from "../assets/CANCELLED.png";
import active from "../assets/ACTIVE.png";
import pending from "../assets/PENDING.png";
import menu from "../assets/menu.png";
import profile from "../assets/profile.png";
import verified from "../assets/verified.png";
import { BlurView } from "expo-blur";
import * as Location from "expo-location";
import axios from "axios";
import { GOOGLE_MAPS_API_KEY } from "../env";
import { getPlaceID } from "../utils/map";
import i18n from "../components/local";

const BookingDetail = () => {
  const route = useRoute();
  const navigation = useNavigation();
  const [modalVisible, setModalVisible] = useState(false);
  const [modalVisible1, setModalVisible1] = useState(false);
  const [data, setData] = useState<Booking>(route.params.data);
  const id = route.params.id;
  const [refresh, setRefresh] = useState(route.params.refresh || false);
  const [status, setStatus] = useState<Number>(data.status);

  const [origin, setOrigin] = useState<any>(data.origin);
  const [destination, setDestination] = useState<any>(data.destination);

  const [duration, setDuration] = useState<any>("");
  const [distance, setDistance] = useState<any>("");

  const [otp, setOtp] = useState<string>("");

  const fetchData = async () => {
    try {
      const res = await axiosInstance.get(`booking/${id}`);
      if (res.status == 200) {
        setData(res.data.data);
        setStatus(res.data.data.status);
      }
    } catch (error) {
      console.log(error);
    } finally {
      setRefresh(false);
    }
  };

  useEffect(() => {
    if (refresh || data.id !== id) {
      fetchData();
    }
  }, []);

  useEffect(() => {
    if (status === 3) {
      setDestination(origin);
    }
  }, [status]);

  const MINUTE_MS = 10000; // milliseconds in a minute

  useEffect(() => {
    const interval = setInterval(async () => {
      if (status === 3 || status === 4) {
        let location = await Location.getCurrentPositionAsync({});

        const origin1 = await getPlaceID(
          location.coords.latitude,
          location.coords.longitude
        );

        setOrigin({
          lat: location.coords.latitude,
          lng: location.coords.longitude,
          formatedAddress: origin1.formatted_address,
          placeId: origin1.placeId,
        });
      }
    }, MINUTE_MS);

    return () => clearInterval(interval); // This represents the unmount function, in which you need to clear your interval to prevent memory leaks.
  }, []);

  useEffect(() => {
    if (!origin || !destination) return;

    // get the distance between two points and time using google maps api

    const getDistance = async () => {
      try {
        const res = await fetch(
          `https://maps.googleapis.com/maps/api/distancematrix/json?units=imperial&origins=place_id:${origin.placeId}&destinations=place_id:${destination.placeId}&key=${GOOGLE_MAPS_API_KEY}`
        );
        const data = await res.json();

        setDuration(data.rows[0].elements[0].duration.text);
        setDistance(data.rows[0].elements[0].distance.text);
      } catch (error) {
        console.log(error);
      }
    };

    getDistance();
  }, [origin, destination]);

  //// 0: pending, 1: bookingDone, 2: accepted, 3:startedV1, 4:startedV2  5: complete 6: canceld 7: rejected

  // o : payment pending from user side
  // 1 : payment done from user side booking done
  // 2 : accepted by driver
  // 3 : started from driver side ( driver location to origin location )
  // 4 : started from user side ( origin location to  destination location )
  // 5 : completed
  // 6 : cancelled by user
  // 7 : rejected by driver or admin ( if driver reject the booking )

  const statuss = [
    { id: 0, image: pending },
    { id: 1, image: booking },
    { id: 2, image: accepted },
    { id: 3, image: booking },
    { id: 5, image: active },
    { id: 6, image: cancelled },
  ];

  const StartPickUp = async () => {
    try {
      const res = await axiosInstance.post(`driver/booking/${id}/start1`);
      if (res.status == 200) {
        fetchData();
      }
    } catch (error) {
      console.log(error);
    }
  };

  const StartDropUp = async () => {
    try {
      const res = await axiosInstance.post(`driver/booking/${id}/start2`, {
        otp: otp,
      });
      if (res.status == 200) {
        fetchData();
      }
    } catch (error) {
      console.log(error);
    } finally {
      setOtp("");
      setModalVisible(false);
    }
  };

  const Completed = async () => {
    try {
      const res = await axiosInstance.post(`driver/booking/${id}/complete`);
      if (res.status == 200) {
        fetchData();
      }
    } catch (error) {
      console.log(error);
    } finally {
      setOtp("");
      setModalVisible1(false);
    }
  };

  return (
    <SafeAreaView>
      <ScrollView
        refreshControl={
          <RefreshControl refreshing={refresh} onRefresh={fetchData} />
        }
      >
        <>
          <TouchableOpacity
            style={tw`bg-gray-50 absolute top-8 left-4 z-50 p-3 rounded-full shadow-lg`}
          >
            <Image source={menu} />
          </TouchableOpacity>
          <Map1 origin={origin} destination={destination}></Map1>

          <View>
            <Modal
              animationType="slide"
              transparent={true}
              visible={modalVisible}
            >
              <View style={styles.m}>
                <Text>Enter the OTP</Text>
                <TextInput
                  style={styles.input}
                  value={otp}
                  onChangeText={(text) => setOtp(text)}
                />
                <View style={styles.bottom}>
                  <TouchableOpacity
                    style={[styles.btn, { backgroundColor: "#5745C6" }]}
                    onPress={() => {
                      setModalVisible(false);
                    }}
                  >
                    <Text
                      style={{
                        color: "white",
                        fontWeight: "700",
                        fontSize: 18,
                      }}
                    >
                      cencel
                    </Text>
                  </TouchableOpacity>

                  <TouchableOpacity
                    style={[styles.btn, { backgroundColor: "#5745C6" }]}
                    onPress={() => {
                      StartDropUp();
                    }}
                  >
                    <Text
                      style={{
                        color: "white",
                        fontWeight: "700",
                        fontSize: 18,
                      }}
                    >
                      Verify and Start
                    </Text>
                  </TouchableOpacity>
                </View>
              </View>
            </Modal>

            <Modal
              animationType="slide"
              transparent={true}
              visible={modalVisible1}
            >
              <View style={styles.m}>
                {data.bookingPayment.bookingUserPayment.userPaymentStatus ===
                  0 && (
                  <>
                    <View>
                      <View style={styles.total}>
                        <Text
                          style={{
                            fontSize: 15,
                            fontStyle: "italic",
                            fontWeight: "700",
                          }}
                        >
                           {i18n.t('total')} {i18n.t('amount')}
                        </Text>
                        <Text style={{ fontSize: 30, fontWeight: "700" }}>
                          INR {data.bookingPayment.amount} /-
                        </Text>
                      </View>
                    </View>
                    <View style={styles.bottom}>
                      <TouchableOpacity
                        style={[styles.btn, { backgroundColor: "#5745C6" }]}
                        onPress={() => {
                          setModalVisible1(false);
                        }}
                      >
                        <Text
                          style={{
                            color: "white",
                            fontWeight: "700",
                            fontSize: 18,
                          }}
                        >
                           {i18n.t('cencel')}
                        </Text>
                      </TouchableOpacity>

                      <TouchableOpacity
                        style={[styles.btn, { backgroundColor: "#5745C6" }]}
                        onPress={() => {
                          Completed();
                        }}
                      >
                        <Text
                          style={{
                            color: "white",
                            fontWeight: "700",
                            fontSize: 18,
                          }}
                        >
                       {i18n.t('confirmPayment')}  
                        </Text>
                      </TouchableOpacity>
                    </View>
                  </>
                )}
              </View>
            </Modal>
            <BlurView
              style={{ borderTopRightRadius: 50 }}
              intensity={modalVisible === true ? 100 : 1}
            >
              <Text
                style={[
                  tw`mt-14 ml-10`,
                  { color: "#35619C", fontSize: 18, fontWeight: "700" },
                ]}
              >
                {data?.user?.name}
              </Text>
              <Text
                style={[
                  tw`ml-10 mt-3`,
                  {
                    color: "#265679",
                    fontSize: 17,
                    lineHeight: 23.12,
                    fontWeight: "400",
                  },
                ]}
              >
               {i18n.t('pickup')}   : {data.origin.formatedAddress}
              </Text>
              <Text
                style={[
                  tw`ml-10 mt-2`,
                  {
                    color: "#265679",
                    fontSize: 17,
                    lineHeight: 23.12,
                    fontWeight: "400",
                  },
                ]}
              >
                {i18n.t('drop')} : {data.destination.formatedAddress}
              </Text>
              <View style={styles.r}>
                <Text style={{ fontSize: 20, fontWeight: "600" }}>157 KGs</Text>
                <Text
                  style={{ color: "#35619C", fontSize: 15, fontWeight: "400" }}
                >
                  {i18n.t('cargo')}  {i18n.t('weight')} 
                </Text>
              </View>
              {data.status == 3 && (
                <View style={styles.mid}>
                  <Text style={styles.midText}>
                    You arrived at the pick-up location in {duration} and{" "}
                    {distance}
                  </Text>
                </View>
              )}
              {data.status == 4 && (
                <View style={styles.mid}>
                  <Text style={styles.midText}>
                    You arrived at the drop-up location in {duration} and{" "}
                    {distance}
                  </Text>
                </View>
              )}

              <View style={styles.bottom}>
                <View>
                  <Text style={styles.t1}>
                    {" "}
                    {data.expectedTime.expectedTravelTime}{" "}
                  </Text>
                  <Text style={styles.t2}>{i18n.t('expectedTravelTime')}   </Text>
                </View>
                <View>
                  <Text style={styles.t3}>
                    {data.expectedDistance.value / 1000} Km
                  </Text>
                  <Text style={styles.t4}> {i18n.t('expectedDistance')}  </Text>
                </View>
              </View>
              <View style={styles.bottom}>
                {status === 2 && (
                  <TouchableOpacity
                    style={[styles.btn, { backgroundColor: "#5745C6" }]}
                    onPress={StartPickUp}
                  >
                    <Text
                      style={{
                        color: "white",
                        fontSize: 14,
                        fontWeight: "700",
                      }}
                    >
                      {i18n.t('startPickup')}
                    </Text>
                  </TouchableOpacity>
                )}

                {status === 3 && (
                  <TouchableOpacity
                    style={[styles.btn, { backgroundColor: "#5745C6" }]}
                    onPress={() => setModalVisible(true)}
                  >
                    <Text
                      style={{
                        color: "white",
                        fontSize: 14,
                        fontWeight: "700",
                      }}
                    >
                      {i18n.t('startDropup')}
                    </Text>
                  </TouchableOpacity>
                )}

                {status === 4 && (
                  <TouchableOpacity
                    style={[styles.btn, { backgroundColor: "#5745C6" }]}
                    onPress={() => setModalVisible1(true)}
                  >
                    <Text
                      style={{
                        color: "white",
                        fontSize: 14,
                        fontWeight: "700",
                      }}
                    >
                      {i18n.t('complete')}
                    </Text>
                  </TouchableOpacity>
                )}

                {status < 5 && (
                  <TouchableOpacity
                    style={[styles.btn, { backgroundColor: "#B51600" }]}
                  >
                    <Text
                      style={{
                        color: "white",
                        fontSize: 14,
                        fontWeight: "700",
                      }}
                    >
                      Cancel Ride
                    </Text>
                  </TouchableOpacity>
                )}

                {status === 5 && (
                  <View style={styles.ver}>
                    <View>
                      <Text style={{ fontSize: 25, fontWeight: "bold" }}>
                       {i18n.t('booking')}  
                      </Text>
                      <Text style={{ fontSize: 25, fontWeight: "bold" }}>
                      {i18n.t('completed')}
                      </Text>
                    </View>
                    <Image source={verified} />
                  </View>
                )}
              </View>
            </BlurView>
          </View>
        </>
      </ScrollView>
    </SafeAreaView>
  );
};

export default BookingDetail;

const styles = StyleSheet.create({
  map: {
    height: 448,
    backgroundColor: "green",
  },
  r: {
    position: "absolute",
    top: 60,
    right: 20,
  },
  t1: {
    fontSize: 16,
    lineHeight: 21.76,
    fontWeight: "300",
  },
  t2: {
    fontSize: 13,
    fontWeight: "bold",
  },
  t3: {
    fontSize: 15,
    fontStyle: "italic",
    fontWeight: "600",
  },
  t4: {
    fontSize: 13,
  },
  mid: {
    backgroundColor: "#6171FF",
    justifyContent: "center",
    alignItems: "center",
    height: 65,
    marginVertical: 30,
  },
  midText: {
    color: "white",
    textAlign: "center",
    width: 228,
    fontSize: 17,
    fontStyle: "italic",
    fontWeight: "600",
  },
  bottom: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginHorizontal: 26,
  },
  btn: {
    width: 151,
    height: 52,
    borderRadius: 20,
    justifyContent: "center",
    alignItems: "center",
  },
  circleExpand: {
    position: "absolute",
    backgroundColor: "white",
    width: 116,
    alignItems: "center",
    borderTopLeftRadius: 999,
    borderTopRightRadius: 999,
    height: 116,
    top: -70,
    justifyContent: "center",
  },
  m: {
    width: 327,
    height: 264,
    borderRadius: 40,
    backgroundColor: "white",
    marginLeft: "auto",
    marginRight: "auto",
    marginTop: "auto",
    marginBottom: "auto",
    justifyContent: "center",
    alignItems: "center",
  },
  input: {
    width: 200,
    height: 41,
    borderRadius: 20,
    borderWidth: 1,
    paddingHorizontal: 20,
  },
  otp: {
    width: 260,
    height: 60,
    backgroundColor: "#5745C6",
    bottom: -10,
    borderRadius: 15,
    justifyContent: "center",
    alignItems: "center",
  },
  ver: {
    flexDirection: "row",
    alignItems: "center",
    marginHorizontal: 80,
    marginTop: 30,
  },
  total: {
    justifyContent: "center",
    alignItems: "center",
    marginTop: 20,
  },
});

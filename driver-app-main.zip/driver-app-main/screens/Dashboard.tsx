import {
  StyleSheet,
  Text,
  View,
  SafeAreaView,
  Image,
  TouchableOpacity,
  Platform,
} from "react-native";
import React, { useEffect, useRef, useState } from "react";
import tw from "tailwind-react-native-classnames";
import Menu from "../components/Menu";
import HelloCard from "../components/WelcomeCard";
import accept from "../assets/accept.png";
import notaccept from "../assets/notaccept.png";
import loc from "../assets/loc.png";
import eyelash from "../assets/eyelash.png";
import Footer from "../components/Footer";
import * as Location from "expo-location";
import * as TaskManager from "expo-task-manager";
import { axiosInstance } from "../utils/axios";
import driver, { selectDriver } from "../store/slices/driver";
import { useSelector } from "react-redux";
import * as Notifications from "expo-notifications";
const LOCATION_TASK_NAME = "LOCATION_TASK_NAME";
import * as Device from "expo-device";
import i18n from "../components/local";
let foregroundSubscription = null;

async function registerForPushNotificationsAsync(id: string) {
  let token;

  if (Platform.OS === "android") {
    await Notifications.setNotificationChannelAsync("default", {
      name: "default",
      importance: Notifications.AndroidImportance.MAX,
      vibrationPattern: [0, 250, 250, 250],
      lightColor: "#FF231F7C",
    });
  }

  if (Device.isDevice) {
    const { status: existingStatus } =
      await Notifications.getPermissionsAsync();
    let finalStatus = existingStatus;
    if (existingStatus !== "granted") {
      const { status } = await Notifications.requestPermissionsAsync();
      finalStatus = status;
    }
    if (finalStatus !== "granted") {
      alert("Failed to get push token for push notification!");
      return;
    }
 

    token = (await Notifications.getExpoPushTokenAsync()).data;
    console.log(id);
    

    axiosInstance.post(`driver/set/token/${id}`, {
      notificationToken: token,


    });
  } else {
    alert("Must use physical device for Push Notifications");
  }

  return token;
}

Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldPlaySound: false,
    shouldSetBadge: false,
  }),
});

const Dashboard = () => {
  const [isAccepting, setIsAccepting] = useState(false);

  // Define position state: {latitude: number, longitude: number}
  const [position, setPosition] = useState(null);
  const driver = useSelector(selectDriver);

  const [expoPushToken, setExpoPushToken] = useState("");
  const [notification, setNotification] = useState(false);
  const notificationListener = useRef();
  const responseListener = useRef();

  useEffect(() => {
    registerForPushNotificationsAsync(driver.id).then((token) =>
      setExpoPushToken(token)
    );

    notificationListener.current =
      Notifications.addNotificationReceivedListener((notification) => {
        setNotification(notification);
      });

    responseListener.current =
      Notifications.addNotificationResponseReceivedListener((response) => {
        console.log(response);
      });

    return () => {
      Notifications.removeNotificationSubscription(
        notificationListener.current
      );
      Notifications.removeNotificationSubscription(responseListener.current);
    };
  }, []);

  // Define the background task for location tracking
  TaskManager.defineTask(LOCATION_TASK_NAME, async ({ data, error }) => {
    if (error) {
      console.error(error);
      return;
    }

    if (data) {
      // Extract location coordinates from data
      const { locations } = data;
      const location = locations[0];
      if (location) {
        // console.log("Location in background", location,driver);
        //  await axiosInstance.post(`driver/set/location/${driver.id}`, location.coords)
      }
    }
  });

  // Request permissions right after starting the app
  useEffect(() => {
    const requestPermissions = async () => {
      const foreground = await Location.requestForegroundPermissionsAsync();
      if (foreground.granted)
        await Location.requestBackgroundPermissionsAsync();
      await startBackgroundUpdate();
    };
    requestPermissions();
  }, []);
 

  // Start location tracking in background
  const startBackgroundUpdate = async () => {
    // Don't track position if permission is not granted
    const { granted } = await Location.getBackgroundPermissionsAsync();
    if (!granted) {
      console.log("location tracking denied");
      return;
    }

    // Make sure the task is defined otherwise do not start tracking
    const isTaskDefined = await TaskManager.isTaskDefined(LOCATION_TASK_NAME);
    if (!isTaskDefined) {
      console.log("Task is not defined");
      return;
    }

    // Don't track if it is already running in background
    const hasStarted = await Location.hasStartedLocationUpdatesAsync(
      LOCATION_TASK_NAME
    );
    if (hasStarted) {
      console.log("Already started");
      return;
    }

    await Location.startLocationUpdatesAsync(LOCATION_TASK_NAME, {
      // For better logs, we set the accuracy to the most sensitive option
      accuracy: Location.Accuracy.BestForNavigation,
      // Make sure to enable this notification if you want to consistently track in the background
      showsBackgroundLocationIndicator: true,
      foregroundService: {
        notificationTitle: "Location",
        notificationBody: "Location tracking in background",
        notificationColor: "#fff",
      },

      // We use the most aggressive interval for the best accuracy
      timeInterval: 1000,
      distanceInterval: 0,
    });
  };

  return (
    <SafeAreaView style={[tw`flex-1`, { backgroundColor: "#fefeff" }]}>
      <Text
        style={[
          tw`mx-auto mt-10 text-xl`,
          { fontFamily: "Mulish_700Bold", color: "#3E4958" },
        ]}
      >
         {i18n.t('dashboard')}
      </Text>
      <Menu />
      <HelloCard />
      <TouchableOpacity
        onPress={() => setIsAccepting(!isAccepting)}
        style={tw`-mt-10`}
      >
        {isAccepting === true ? (
          <View>
            <Image source={accept} />
            <Image source={loc} style={tw`absolute top-36 left-40 ml-2`} />
            <Text
              style={[
                tw`absolute top-48 left-36 text-lg ml-1`,
                { fontFamily: "Mulish_700Bold" },
              ]}
            >
              {i18n.t('accept')}
            </Text>
            <Text
              style={[
                tw`absolute top-52 left-36 text-lg ml-2 mt-1`,
                { fontFamily: "Mulish_700Bold" },
              ]}
            >
              {i18n.t('bookings')}
            </Text>
          </View>
        ) : (
          <View>
            <Image source={notaccept} />
            <Image source={eyelash} style={tw`absolute top-36 left-36`} />
            <Image source={eyelash} style={tw`absolute top-36 left-48`} />
            <Text
              style={[
                tw`absolute top-48 left-40 text-lg ml-3`,
                { fontFamily: "Mulish_700Bold" },
              ]}
            >
              {i18n.t('notaccepting')}
            </Text>
            <Text
              style={[
                tw`absolute top-52 left-36 text-lg mt-1 ml-1`,
                { fontFamily: "Mulish_700Bold" },
              ]}
            >
              {i18n.t('accept')}
            </Text>
          </View>
        )}
      </TouchableOpacity>
      <Footer />
    </SafeAreaView>
  );
};

export default Dashboard;

const styles = StyleSheet.create({});

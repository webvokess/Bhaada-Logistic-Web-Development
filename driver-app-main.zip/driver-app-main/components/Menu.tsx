import { Image, StyleSheet, Text, TouchableOpacity, View } from "react-native";
import React from "react";
import tw from "tailwind-react-native-classnames";
import menu from "../assets/menu.png";
import { useNavigation } from "@react-navigation/native";

const Menu = () => {
  const navigation = useNavigation();
  return (
    <TouchableOpacity
      style={tw`p-1 rounded-full border w-10 border-gray-200 absolute left-5 top-8`}
      onPress={() => navigation.navigate("MenuScreen")}
    >
      <Image source={menu} />
    </TouchableOpacity>
  );
};

export default Menu;

const styles = StyleSheet.create({});

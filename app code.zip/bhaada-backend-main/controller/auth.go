package controller

import (
	"bhaada-backend/dto"
	"bhaada-backend/model"
	"bhaada-backend/utils"
	"time"

	"github.com/gin-gonic/gin"

	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/bson/primitive"
	"go.mongodb.org/mongo-driver/mongo"
)

func SendOtp(ctx *gin.Context) {

	var req dto.CreateOtpRequest

	if err := ctx.ShouldBindJSON(&req); err != nil {
		ctx.JSON(400, gin.H{
			"message": "invalid request",
			"error":   err.Error(),
		})
		return
	}

	if req.Mobile == "" {
		ctx.JSON(400, gin.H{
			"message": "mobile is required",
		})
		return
	}

	otp := GenerateOtp(req.Mobile)

	authOtp := model.AuthOtp{
		Otp:       otp,
		Mobile:    req.Mobile,
		Expired:   time.Now().Add(time.Minute * 5),
		CreatedAt: time.Now(),
		Status:    0,
	}

	res, err := model.AuthOtpCollection().InsertOne(ctx, authOtp)

	if err != nil {
		ctx.JSON(500, gin.H{
			"message": err.Error(),
		})

		return

	}

	ctx.JSON(200, gin.H{
		"message": "otp sent",
		"data": gin.H{
			"otp":     otp,
			"id":      res.InsertedID.(primitive.ObjectID).Hex(),
			"mobile":  req.Mobile,
			"expired": authOtp.Expired,
			"status":  authOtp.Status,
		},
	})

}

func VerifyOtp(ctx *gin.Context) {

	var req dto.VerifyOtpRequest

	if err := ctx.ShouldBindJSON(&req); err != nil {
		ctx.JSON(400, gin.H{
			"message": "invalid request",
			"error":   err.Error(),
		})
		return
	}

	if req.Validate() != nil {
		ctx.JSON(400, gin.H{
			"message": "invalid request",
			"error":   req.Validate().Error(),
		})
		return
	}

	otp := model.AuthOtp{}
	id, err := primitive.ObjectIDFromHex(req.Id)

	if err != nil {
		ctx.JSON(400, gin.H{
			"message": "invalid request",
			"error":   err.Error(),
		})
		return
	}

	if err := model.AuthOtpCollection().FindOne(ctx, bson.M{"_id": id}).Decode(&otp); err != nil {

		ctx.JSON(500, gin.H{
			"message": err.Error(),
		})

		return

	}

	if !otp.IsValid(req.Otp) {

		ctx.JSON(400, gin.H{
			"message": "invalid otp",
		})

		return

	}

	otp.Status = 1

	var user model.User

	err = model.UserCollection().FindOne(ctx, bson.M{"mobile": otp.Mobile}).Decode(&user)

	if err != mongo.ErrNoDocuments && err != nil {
		ctx.JSON(500, gin.H{
			"message": err.Error(),
		})

		return
	}

	if user.Id.Hex() == "000000000000000000000000" {
		user.Id = primitive.NewObjectID()
		user.Mobile = req.Mobile
		user.CreatedAt = time.Now()
		user.UpdatedAt = time.Now()

		_, err = model.UserCollection().InsertOne(ctx, user)

		if err != nil {
			ctx.JSON(500, gin.H{
				"message": err.Error(),
			})

			return

		}

	}

	jwtString, err := utils.CreateJWT(user.Id.Hex(), utils.AccessTokenExpired)

	if err != nil {
		ctx.JSON(500, gin.H{
			"message": err.Error(),
		})

		return
	}

	refreshToken := model.AuthRefreshToken{
		UserId:    user.Id,
		CreatedAt: time.Now(),
		Expired:   time.Now().Add(utils.RefreshTokenExpired),
	}

	res, err := model.RefreshTokenCollection().InsertOne(ctx, refreshToken)

	if err != nil {
		ctx.JSON(500, gin.H{
			"message": err.Error(),
		})

		return
	}

	refreshToken.Id = res.InsertedID.(primitive.ObjectID)

	refreshTokenJwtString, err := utils.CreateJWT(refreshToken.Id.Hex(), utils.RefreshTokenExpired)

	if err != nil {
		ctx.JSON(500, gin.H{
			"message": err.Error(),
		})

		return
	}

	_, err = model.AuthOtpCollection().UpdateOne(ctx, bson.M{"_id": id}, bson.D{{"$set", otp}})

	if err != nil {
		ctx.JSON(500, gin.H{
			"message": err.Error(),
		})

		return

	}

	ctx.JSON(200, gin.H{
		"message": "otp verified",
		"data": gin.H{
			"token":         jwtString,
			"refresh_token": refreshTokenJwtString,
			"expiredIn":     time.Now().Add(time.Hour * 24 * 7).Unix(),
			"user":          user.ToMap(),
		},
	})

}

func RefreshToken(ctx *gin.Context) {

	var req dto.RefreshTokenRequest

	userId, _ := ctx.Get("user")

	if err := ctx.ShouldBindJSON(&req); err != nil {
		ctx.JSON(400, gin.H{
			"message": "invalid request",
			"error":   err.Error(),
		})
		return
	}

	claims, err := utils.VerifyJWT(req.Token)

	if err != nil {
		ctx.JSON(400, gin.H{
			"message": "invalid token",
			"error":   err.Error(),
		})
		return
	}

	refreshToken := model.AuthRefreshToken{}
	id, err := primitive.ObjectIDFromHex(claims.ID)

	if err != nil {
		ctx.JSON(400, gin.H{
			"message": "invalid request",
			"error":   err.Error(),
		})
		return
	}

	if err := model.RefreshTokenCollection().FindOne(ctx, bson.M{"_id": id}).Decode(&refreshToken); err != nil {

		ctx.JSON(500, gin.H{
			"message": err.Error(),
		})

		return

	}

	if !refreshToken.IsValid(userId.(string)) {
		ctx.JSON(400, gin.H{
			"message": "invalid refresh token",
		})

		return

	}

	user := model.User{}

	err = model.UserCollection().FindOne(ctx, bson.M{"_id": refreshToken.UserId}).Decode(&user)

	if err != mongo.ErrNoDocuments && err != nil {
		ctx.JSON(500, gin.H{
			"message": err.Error(),
		})

		return
	}

	jwtString, err := utils.CreateJWT(user.Id.Hex(), utils.AccessTokenExpired)

	if err != nil {
		ctx.JSON(500, gin.H{
			"message": err.Error(),
		})

		return

	}

	refreshToken.Status = 1

	_, err = model.RefreshTokenCollection().UpdateOne(ctx, bson.M{"_id": id}, bson.D{{"$set", refreshToken}})

	if err != nil {
		ctx.JSON(500, gin.H{
			"message": err.Error(),
		})

		return

	}

	refreshToken = model.AuthRefreshToken{
		UserId:    user.Id,
		CreatedAt: time.Now(),
		Expired:   time.Now().Add(utils.RefreshTokenExpired),
	}

	res, err := model.RefreshTokenCollection().InsertOne(ctx, refreshToken)

	if err != nil {
		ctx.JSON(500, gin.H{
			"message": err.Error(),
		})

		return
	}

	refreshToken.Id = res.InsertedID.(primitive.ObjectID)

	refreshTokenJwtString, err := utils.CreateJWT(refreshToken.Id.Hex(), utils.RefreshTokenExpired)

	if err != nil {
		ctx.JSON(500, gin.H{
			"message": err.Error(),
		})

		return
	}

	ctx.JSON(200, gin.H{

		"message": "refresh token verified",
		"data": gin.H{
			"token":         jwtString,
			"refresh_token": refreshTokenJwtString,
			"expiredIn":     time.Now().Add(time.Hour * 24 * 7).Unix(),
			"user":          user.ToMap(),
		},
	})

}
func GenerateOtp(mobile string) string {
	return "12345"
}

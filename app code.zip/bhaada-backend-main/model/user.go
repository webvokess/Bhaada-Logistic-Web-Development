package model

import (
	"bhaada-backend/db"
	"time"

	"go.mongodb.org/mongo-driver/bson/primitive"
	"go.mongodb.org/mongo-driver/mongo"
)

type User struct {
	Id                primitive.ObjectID `bson:"_id,omitempty" json:"id,omitempty"`
	Email             string             `json:"email" bson:"email"`
	Mobile            string             `json:"mobile" bson:"mobile"`
	Age               int64              `json:"age" bson:"age"`
	Gender            string             `json:"gender" bson:"gender"`
	Avatar            string             `json:"avatar" bson:"avatar"`
	Password          string             `json:"password" bson:"password"`
	CreatedAt         time.Time          `json:"created_at" bson:"created_at"`
	UpdatedAt         time.Time          `json:"updated_at" bson:"updated_at"`
	IsDriver          bool               `json:"is_driver" bson:"is_driver"`
	IsAdmin           bool               `json:"is_admin" bson:"is_admin"`
	IsProfileComplete bool               `json:"is_profile_complete" bson:"is_profile_complete"`
	IsActive          bool               `json:"is_active" bson:"is_active"`
	IsDeleted         bool               `json:"is_deleted" bson:"is_deleted"`
	IsVerified        bool               `json:"is_verified" bson:"is_verified"`
	IsEmailVerified   bool               `json:"is_email_verified" bson:"is_email_verified"`
	IsMobileVerified  bool               `json:"is_mobile_verified" bson:"is_mobile_verified"`
}

func (user *User) ToMap() map[string]interface{} {
	return map[string]interface{}{
		"id":                user.Id.Hex(),
		"email":             user.Email,
		"mobile":            user.Mobile,
		"age":               user.Age,
		"gender":            user.Gender,
		"avatar":            user.Avatar,
		"isDriver":          user.IsDriver,
		"isProfileComplete": user.IsProfileComplete,
		"isActive":          user.IsActive,
		"isEmailVerified":   user.IsEmailVerified,
		"isMobileVerified":  user.IsMobileVerified,
	}

}

func UserCollection() *mongo.Collection {
	return db.GetClient().Collection("users")
}

import {
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";
import React from "react";
import tw from "tailwind-react-native-classnames";
import i18n from "../components/local";

const Support = () => {
  return (
    <View style={{ backgroundColor: "#a3c6f8", flex: 1 }}>
      <Text style={tw`mt-20 text-center text-3xl font-bold`}> {i18n.t('support')} !</Text>
      <Text style={tw`mt-14 ml-10 text-xl font-bold`}>
       {i18n.t('contactNumber')}   : <Text style={tw`text-red-800`}>+91 77777699</Text>
      </Text>
      <Text style={tw`mt-5 ml-10 text-xl font-bold`}>
         {i18n.t('email')}  : <Text style={tw`text-red-800`}>support@bhaada.co.in</Text>
      </Text>
      <Text style={tw`mt-10 text-center italic text-base`}>
      {i18n.t('enterYourQuery')} ...
      </Text>
      <TextInput multiline={true} numberOfLines={4} style={styles.input} />
      <TouchableOpacity style={styles.btn}>
        <Text style={tw`text-white text-xl font-bold`}>Submit</Text>
      </TouchableOpacity>
    </View>
  );
};

export default Support;

const styles = StyleSheet.create({
  input: {
    borderWidth: 1,
    marginHorizontal: 30,
    borderColor: "gray",
    backgroundColor: "white",
  },
  btn: {
    width: 200,
    height: 52,
    backgroundColor: "#5745C6",
    justifyContent: "center",
    alignItems: "center",
    borderRadius: 20,
    marginTop: 30,
    marginLeft: "auto",
    marginRight: "auto",
  },
});

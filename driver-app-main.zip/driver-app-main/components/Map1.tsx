import MapView, {
  Marker,
  Circle,
  Callout,
  PROVIDER_GOOGLE,
} from "react-native-maps";
import React, { useEffect, useRef } from "react";

import { GOOGLE_MAPS_API_KEY } from "../env";
import MapViewDirections from "react-native-maps-directions";

import { Animated, Dimensions, StyleSheet, Text, View } from "react-native";

const Map1 = ({ origin, destination }) => {
  const mapRef = useRef<MapView>(null);
  const destinationRef = useRef<Marker>(null);

  const onMapReady = () => {
    mapRef.current?.fitToCoordinates(
      [
        {
          latitude: origin?.lat,
          longitude: origin?.lng,
        },
        {
          latitude: destination?.lat,
          longitude: destination?.lng,
        },
      ],
      {
        edgePadding: { top: 50, right: 50, bottom: 50, left: 50 },
      }
    );

    destinationRef.current?.showCallout();
  };

  return (
    <MapView
      ref={mapRef}
      style={{
        width: Dimensions.get("window").width - 10,
        height: Dimensions.get("window").height * 0.6,

        flex: 1,
      }}
      onMapReady={onMapReady}
      zoomControlEnabled={true}
      provider={PROVIDER_GOOGLE}
    >
      {origin && destination && (
        <MapViewDirections
          origin={origin.formatedAddress}
          destination={destination.formatedAddress}
          apikey={GOOGLE_MAPS_API_KEY}
          strokeWidth={3}
          strokeColor="blue"
          onReady={(result) => {
            console.log(result.distance, result.duration);
          }}
        />
      )}

      <Circle
        center={{
          latitude: destination.lat,
          longitude: destination.lng,
        }}
        radius={1000}
        zIndex={-1}
        fillColor="#ddddff"
      ></Circle>

      <Marker
        coordinate={{
          latitude: destination.lat,
          longitude: destination.lng,
        }}
        title="destination"
        description={destination.formatedAddress}
        identifier="destination"
        
      ></Marker>

      <Marker
        coordinate={{
          latitude: origin.lat,
          longitude: origin.lng,
        }}
        title="Origin"
        description={origin.formatedAddress}
        // image={{uri: 'custom_pin'}}
        identifier="origin"
      ></Marker>
    </MapView>
  );
};

export default Map1;

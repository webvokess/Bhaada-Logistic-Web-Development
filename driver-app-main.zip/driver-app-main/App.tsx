import { configureStore } from "@reduxjs/toolkit";
import { StatusBar } from "expo-status-bar";
import { SafeAreaProvider } from "react-native-safe-area-context";
import { applyMiddleware, createStore, Store } from "redux";
import thunk from "redux-thunk";
import {LogBox} from "react-native";
import useCachedResources from "./hooks/useCachedResources";

 
import Navigation from "./navigation";
import reducer from "./store/auth";
import { Provider } from "react-redux";
import { store } from "./store/store";


import { useEffect, useState } from "react";
import * as Permissions from 'expo-permissions';
import { axiosInstance } from "./utils/axios";







export default function App() {
  const isLoadingComplete = useCachedResources();


 
  // LogBox.ignoreLogs([
  //   "ViewPropTypes will be removed",
  //   "ColorPropType will be removed",
  //   ])

  if (!isLoadingComplete) {
    return null;
  } else {
    return (
      <Provider store={store}>
        <SafeAreaProvider>
          <Navigation   />
          <StatusBar />
        </SafeAreaProvider>
      </Provider>
    );
  }
}
 


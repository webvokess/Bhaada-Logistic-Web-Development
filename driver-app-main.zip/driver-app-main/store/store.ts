import { configureStore } from "@reduxjs/toolkit";

import tokenReducer from "./slices/tokens";
import driverReducer from "./slices/driver";
import bookingReducer from "./slices/bookingsSlice";

export const store = configureStore({
  reducer: { token: tokenReducer, driver: driverReducer,booking:bookingReducer},
});

export type RootState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;

import { PayloadAction, createSlice } from "@reduxjs/toolkit";

import { RootState } from "../store";

const initialState: Tokens = {
  accessToken: null,
  refreshToken: null,
  expiredIn: null,
};

export const tokenSlice = createSlice({
  name: "token",
  initialState,
  reducers: {
    setToken: (state, action: PayloadAction<Tokens>) => {
      return {
        ...state,
        ...action.payload,
      };
    },
  },
});

export const { setToken } = tokenSlice.actions;

export const selectAccessToken = (state: RootState) => state.token.accessToken;
export const selectRefreshToken = (state: RootState) =>
  state.token.refreshToken;
export const selectExpiredIn = (state: RootState) => state.token.expiredIn;

export default tokenSlice.reducer;

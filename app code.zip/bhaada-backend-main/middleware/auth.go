package middleware

import (
	"bhaada-backend/utils"
	"strings"

	"github.com/gin-gonic/gin"
)

func Auth(ctx *gin.Context) {

	token := ctx.GetHeader("Authorization")

	arr := strings.Split(token, " ")

	if len(arr) != 2 {
		ctx.JSON(401, gin.H{
			"message": "invalid token",
		})

		ctx.Abort()

		return
	}

	claims, err := utils.VerifyJWT(arr[1])

	if err != nil {
		ctx.JSON(401, gin.H{
			"message": "unauthorized",
		})

		ctx.Abort()

		return

	}

	ctx.Set("user", claims.ID)

	ctx.Next()

}

import {
  StyleSheet,
  Text,
  View,
  SafeAreaView,
  Image,
  TouchableOpacity,
  ScrollView,
  RefreshControl,
} from "react-native";
import React, { useEffect, useState } from "react";
import tw from "tailwind-react-native-classnames";
import { useNavigation } from "@react-navigation/native";
import arrow from "../assets/arrow.png";
import accept from "../assets/accept.png";
import notaccept from "../assets/notaccept.png";
import { axiosInstance } from "../utils/axios";
import { useSelector } from "react-redux";
import { selectDriverId } from "../store/slices/driver";
import { Booking, PreBooking } from "../types/booking";
import Swiper from "react-native-swiper";
import Dash from "react-native-dash";
import format from "date-fns/format";
import i18n from "../components/local";

const Bookings = () => {
  const navigation = useNavigation();
  const driverId = useSelector(selectDriverId);
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [prevBookings, setPrevBookings] = useState<PreBooking[]>([]);
  const [refresh, setRefresh] = useState(false);

  const FetchData = async () => {
    const response = await axiosInstance.get(
      `/bookings?driverId=${driverId}&status=1&user=1`
    );

    if (response.status === 200) {
      if (response.data.data && response.data.data.length > 0) {
        setBookings(response.data.data);
      }
    }

    const prevResponse = await axiosInstance.get(
      `driver/pre_Bookings/${driverId}`
    );

    if (prevResponse.status === 200) {
      if (prevResponse.data.data && prevResponse.data.data.length > 0) {
        setPrevBookings(prevResponse.data.data);
      }
    }
  };

  const onAccept = async (bookingId: string, type: string) => {
    let url = `/driver/booking/${bookingId}/accept`;
    if (type === "preBooking") {
      url = `/pre_booking/${bookingId}/accept`;
    }
    const response = await axiosInstance.post(
      url,

      {}
    );

    if (response.status === 200) {
      console.log(response.data);

      FetchData();
    }
  };

  // merge boookings and prebookings
  function DriverBookings() {
    let driverBookings: { booking: Booking; type: string; id: string }[] = [];
    bookings.forEach((booking) => {
      driverBookings.push({
        booking: booking,
        type: "booking",
        id: booking.id,
      });
    });

    prevBookings.forEach((booking) => {
      driverBookings.push({
        booking: booking.booking,
        type: "preBooking",
        id: booking.id,
      });
    });

    return driverBookings;
  }

  const onReject = async (bookingId: string, type: string) => {
    let url = `/driver/booking/${bookingId}/reject`;
    if (type === "preBooking") {
      url = `/pre_booking/${bookingId}/reject`;
    }
    const response = await axiosInstance.post(url, {});

    if (response.status === 200) {
      console.log(response.data);

      FetchData();
    }
  };

  useEffect(() => {
    FetchData();
  }, []);

  return (
    <SafeAreaView style={{ backgroundColor: "#6eacfe", flex: 1 }}>
      <ScrollView
        refreshControl={
          <RefreshControl refreshing={refresh} onRefresh={FetchData} />
        }
      >
        <View style={tw`flex-row items-center pt-10 px-5`}>
          <TouchableOpacity
            onPress={() => navigation.goBack()}
            style={tw`rounded-full p-2 border-white border bg-white`}
          >
            <Image source={arrow} />
          </TouchableOpacity>
          <Text
            style={[
              tw`text-xl ml-20`,
              { fontFamily: "Mulish_700Bold", color: "#3E4958" },
            ]}
          >
            Bhaada App
          </Text>
        </View>
        <Text
          style={[
            tw`text-white text-2xl mx-auto mt-10`,
            { fontFamily: "Mulish_700Bold" },
          ]}
        >
          {DriverBookings().length > 0
            ? `You have ${DriverBookings().length} bookings`
            : `You have no bookings`}
        </Text>

        <Swiper loop={true} showsPagination={false} autoplay>
          {DriverBookings().length > 0 &&
            DriverBookings().map((booking) => (
              <>
                <View
                  style={[
                    tw`mx-auto border mt-5 border-gray-900 pb-3 pl-3 pt-3`,
                    styles.mid,
                  ]}
                >
                  <View style={tw`flex-row justify-between items-center mt-1`}>
                    <Text style={{ color: "#487588", fontSize: 14 }}>
                      {format(
                        new Date(
                          booking.booking.expectedTime?.estimatedDepartureTime
                        ),
                        "d MMM mm:hh"
                      )}
                    </Text>
                    <Text style={{ fontSize: 18, color: "#7EAB3A" }}>●</Text>
                    <Text
                      style={{ fontSize: 16, color: "#3E4958", width: 130 }}
                    >
                      {booking.booking.origin.formatedAddress}
                    </Text>
                  </View>
                  <View
                    style={[
                      tw`w-px h-7 `,
                      { backgroundColor: "#3E4958", marginLeft: 92 },
                    ]}
                  />
                  <View style={tw`flex-row justify-between items-center -mt-3`}>
                    <Text style={{ color: "#487588", fontSize: 14 }}>
                      {format(
                        new Date(
                          booking.booking.expectedTime?.estimatedArrivalTime
                        ),
                        "d MMM mm:hh"
                      )}
                    </Text>
                    <Text style={{ fontSize: 18, color: "#B53131" }}>▼</Text>
                    <Text
                      style={{ fontSize: 16, color: "#3E4958", width: 130 }}
                    >
                      {booking.booking.destination.formatedAddress}
                    </Text>
                  </View>
                </View>
                <View style={styles.cl}>
                  <Text
                    style={{
                      fontSize: 16,
                      fontWeight: "600",
                      fontStyle: "italic",
                    }}
                  >
                    {booking.booking.user.name}
                  </Text>
                  <Text style={{ fontSize: 13, fontWeight: "400" }}>
                    {i18n}
                  </Text>
                </View>
                <View style={styles.cl}>
                  <Text
                    style={{
                      fontSize: 16,
                      fontWeight: "600",
                      fontStyle: "italic",
                    }}
                  >
                    {booking.booking.bookingPayment.amount}
                  </Text>
                  <Text style={{ fontSize: 13, fontWeight: "400" }}>
                    Booking Amount
                  </Text>
                </View>
                <View style={styles.ab}>
                  <Text
                    style={{
                      fontSize: 16,
                      fontWeight: "600",
                      fontStyle: "italic",
                    }}
                  >
                    {
                      booking.booking.bookingPayment.bookingUserPayment
                        .userPaymentMode
                    }
                  </Text>
                  <Text style={{ fontSize: 13, fontWeight: "400" }}>
                    Payment Mode
                  </Text>
                </View>
                <View style={tw`flex-row bottom-20 left-0 right-2 absolute`}>
                  <TouchableOpacity
                    onPress={() => onAccept(booking.id, booking.type)}
                  >
                    <Image
                      source={accept}
                      style={{
                        width: 210,
                        height: 220,
                        resizeMode: "contain",
                        marginLeft: -10,
                      }}
                    />
                  </TouchableOpacity>
                  <TouchableOpacity
                    onPress={() => onReject(booking.booking.id, booking.type)}
                  >
                    <Image
                      source={notaccept}
                      style={{ width: 220, height: 220, resizeMode: "contain" }}
                    />
                  </TouchableOpacity>
                  <Text
                    style={[
                      tw`absolute top-24 text-xl`,
                      { fontFamily: "Mulish_700Bold", left: 77 },
                    ]}
                  >
                    YES
                  </Text>
                  <Text
                    style={[
                      tw`absolute top-24 text-xl `,
                      { fontFamily: "Mulish_700Bold", right: 57 },
                    ]}
                  >
                    NO
                  </Text>
                </View>
              </>
            ))}
        </Swiper>
      </ScrollView>
    </SafeAreaView>
  );
};

export default Bookings;

const styles = StyleSheet.create({
  mid: {
    width: 293,
    borderRadius: 15,
    backgroundColor: "#d5d6fe",
  },
  cl: {
    marginHorizontal: 50,
    marginTop: 40,
  },
  ab: {
    position: "absolute",
    right: 50,
    top: 275,
  },
});

import React, { Component } from "react";
import {
  Text,
  ImageBackground,
  TextInput,
  TouchableOpacity,
  Image,
  Animated,
  Dimensions,
  Keyboard,
  Platform,
  EmitterSubscription,
  Button,
} from "react-native";
import { View } from "../components/Themed";
import { Icon } from "native-base";
const HEIGHT_WINDOW = Dimensions.get("window").height;
import * as Animatable from "react-native-animatable";
import { NativeBaseProvider } from "native-base";
import { Ionicons, FontAwesome } from "@expo/vector-icons";
import { axiosInstance } from "../utils/axios";
import tw from "tailwind-react-native-classnames";
import banner from "../assets/banner.png";

type loginScreenstate = {
  placeholderTxt: string;
  submitBtn: boolean;
  loginHeight: Animated.Value;
  keyboardWillShowListener: EmitterSubscription | null;
  keyboardWillHideListener: EmitterSubscription | null;
  keyboardDidShowListener: EmitterSubscription | null;
  keyboardDidHideListener: EmitterSubscription | null;
  keyboardHeight: Animated.Value;
  forwardArrowOpacity: Animated.Value;
  borderBottomWidth: Animated.Value;
  mobile: string;
};

type loginScreenProps = {
  navigation: any;
};

class SignInScreen extends Component<loginScreenProps> {
  static navigationOptions = {
    header: null,
  };

  state: loginScreenstate = {
    placeholderTxt: "",
    submitBtn: false,
    loginHeight: new Animated.Value(HEIGHT_WINDOW),
    keyboardHeight: new Animated.Value(0),
    forwardArrowOpacity: new Animated.Value(0),
    borderBottomWidth: new Animated.Value(0),
    keyboardWillShowListener: null,
    keyboardWillHideListener: null,
    keyboardDidShowListener: null,
    keyboardDidHideListener: null,
    mobile: "",
  };

  constructor(props: loginScreenProps) {
    super(props);
    this.state = {
      placeholderTxt: "Enter Your Mobile Number",
      loginHeight: new Animated.Value(150),
      keyboardWillShowListener: Keyboard.addListener(
        "keyboardWillShow",
        this.keyboardWillShow
      ),
      keyboardWillHideListener: Keyboard.addListener(
        "keyboardWillHide",
        this.keyboardWillHide
      ),
      keyboardDidShowListener: Keyboard.addListener(
        "keyboardDidShow",
        this.keyboardWillShow
      ),
      keyboardDidHideListener: Keyboard.addListener(
        "keyboardDidHide",
        this.keyboardWillHide
      ),
      keyboardHeight: new Animated.Value(0),
      forwardArrowOpacity: new Animated.Value(0),
      borderBottomWidth: new Animated.Value(0),
    };
  }

  submit = async () => {
    const res = await axiosInstance.post("login/otp", {
      mobile: this.state.mobile,
    });

    if (res.status !== 200) {
      alert("Invalid Credentials");
      return;
    }

    this.props.navigation.navigate("AuthOtp", {
      mobile: this.state.mobile,
      id: res.data.data.id,
    });
  };

  keyboardWillShow = (event: {
    duration: any;
    endCoordinates: { height: number };
  }) => {
    let duration = event.duration;
    if (Platform.OS == "android") {
      duration = 100;
    }

    Animated.parallel([
      Animated.timing(this.state.keyboardHeight, {
        duration: duration + 100,
        toValue: event.endCoordinates.height + 10,
        useNativeDriver: false,
      }),
      Animated.timing(this.state.forwardArrowOpacity, {
        duration: duration,
        toValue: 1,
        useNativeDriver: false,
      }),
      Animated.timing(this.state.borderBottomWidth, {
        duration: duration,
        toValue: 1,
        useNativeDriver: false,
      }),
    ]).start();
  };
  keyboardWillHide = (event: { duration: any }) => {
    let duration = event.duration;
    if (Platform.OS == "android") {
      duration = 100;
    }

    Animated.parallel([
      Animated.timing(this.state.keyboardHeight, {
        duration: duration + 100,
        toValue: 0,
        useNativeDriver: false,
      }),
      Animated.timing(this.state.forwardArrowOpacity, {
        duration: duration,
        toValue: 0,
        useNativeDriver: false,
      }),
      Animated.timing(this.state.borderBottomWidth, {
        duration: duration,
        toValue: 0,
        useNativeDriver: false,
      }),
    ]).start();
  };

  increaseHeightOfLogin = () => {
    this.setState({ placeholderTxt: "4268823942", submitBtn: true });
    Animated.timing(this.state.loginHeight, {
      toValue: HEIGHT_WINDOW,
      duration: 500,
      useNativeDriver: false,
    }).start(() => {
      this.refs.textInputMobile.focus();
    });
  };
  decreaseHeightOfLogin = () => {
    Keyboard.dismiss();
    this.setState({
      placeholderTxt: "Enter Your Mobile Number",
      submitBtn: false,
    });
    Animated.timing(this.state.loginHeight, {
      toValue: 150,
      duration: 500,
      useNativeDriver: false,
    }).start();
  };
  render() {
    const headerTxtOpacity = this.state.loginHeight.interpolate({
      inputRange: [150, HEIGHT_WINDOW],
      outputRange: [1, 0],
    });
    const headerArrowOpacity = this.state.loginHeight.interpolate({
      inputRange: [150, HEIGHT_WINDOW],
      outputRange: [0, 1],
    });

    const marginTop = this.state.loginHeight.interpolate({
      inputRange: [150, HEIGHT_WINDOW],
      outputRange: [25, 100],
    });

    const titleTxtLeft = this.state.loginHeight.interpolate({
      inputRange: [150, HEIGHT_WINDOW],
      outputRange: [100, 25],
    });

    const titleTxtBottom = this.state.loginHeight.interpolate({
      inputRange: [150, 400, HEIGHT_WINDOW],
      outputRange: [0, 0, 100],
    });

    const titleTxtOpacity = this.state.loginHeight.interpolate({
      inputRange: [150, HEIGHT_WINDOW],
      outputRange: [0, 1],
    });

    return (
      <NativeBaseProvider>
        <View style={{ flex: 1 }}>
          <Animated.View
            style={{
              position: "absolute",
              height: 60,
              width: 60,
              top: 60,
              left: 25,
              zIndex: 100,
              opacity: headerArrowOpacity,
            }}
          >
            <TouchableOpacity onPress={() => this.decreaseHeightOfLogin()}>
              <Icon size={"3xl"} as={Ionicons} name="arrow-back" />
            </TouchableOpacity>
          </Animated.View>

          <Animated.View
            style={{
              position: "absolute",
              height: 60,
              width: 60,
              right: 10,
              bottom: this.state.keyboardHeight, //animate,
              opacity: this.state.forwardArrowOpacity, //animate
              zIndex: 100,
              backgroundColor: "#54575e",
              alignItems: "center",
              justifyContent: "center",
              borderRadius: 30,
            }}
          >
            <Icon name="md-arrow-forward" style={{ color: "white" }} />
          </Animated.View>

          <ImageBackground resizeMode={"contain"} source={banner} style={{ flex: 1 , backgroundColor:'gray' }}>
            <Animatable.View
              animation="zoomIn"
              iterationCount={1}
              style={{
                flex: 1,
                justifyContent: "center",
                alignItems: "center",
              }}
            >
              {/* <View
                style={{
                  backgroundColor: "white",
                  height: 200,
                  width: 300,
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                <Image
                  source={require("../assets/images/logo.png")}
                  style={{ height: 180, width: 250 }}
                />
              </View> */}
            </Animatable.View>

            <Animatable.View animation="slideInUp" iterationCount={1}>
              <Animated.View
                style={{
                  height: this.state.loginHeight,
                  backgroundColor: "white",
                }}
              >
                <Animated.View
                  style={{
                    opacity: headerTxtOpacity, //animate
                    alignItems: "flex-start",
                    paddingHorizontal: 25,
                    marginTop: marginTop, //animate
                  }}
                >
                  <Text style={{ fontSize: 20 }}>Get moving with BHAADA</Text>
                </Animated.View>

                <TouchableOpacity onPress={() => this.increaseHeightOfLogin()}>
                  <Animated.View
                    style={{
                      marginTop: marginTop, //animate
                      paddingHorizontal: 25,
                      flexDirection: "row",
                    }}
                  >
                    <Animated.Text
                      style={{
                        fontSize: 25,
                        color: "blue",
                        position: "absolute",
                        bottom: titleTxtBottom,
                        left: titleTxtLeft,
                        opacity: titleTxtOpacity,
                      }}
                    >
                      Enter your mobile number
                    </Animated.Text>

                    <Image
                      source={require("../assets/ve.png")}
                      style={{ height: 24, width: 25, resizeMode: "contain" }}
                    />

                    <Animated.View
                      pointerEvents="none"
                      style={{
                        flexDirection: "row",
                        flex: 1,
                        borderBottomWidth: this.state.borderBottomWidth,
                      }}
                    >
                      <Text
                        style={{ fontSize: 20, paddingHorizontal: 10 }}
                      ></Text>

                      <TextInput
                        keyboardType="numeric"
                        ref="textInputMobile"
                        style={{ flex: 1, fontSize: 20 }}
                        placeholder={this.state.placeholderTxt}
                        underlineColorAndroid="transparent"
                        onChangeText={(text) => this.setState({ mobile: text })}
                      />
                    </Animated.View>
                  </Animated.View>
                </TouchableOpacity>

                {this.state.submitBtn && (
                  <Animated.View>
                    <TouchableOpacity
                      style={tw`bg-blue-500 p-3 mt-10 rounded-full shadow-lg`}
                      onPress={this.submit}
                    >
                      <Text style={tw`text-white text-center`}>Continue</Text>
                    </TouchableOpacity>
                  </Animated.View>
                )}
              </Animated.View>

              <View
                style={{
                  height: 70,
                  backgroundColor: "white",
                  alignItems: "flex-start",
                  justifyContent: "center",
                  borderTopColor: "#e8e8ec",
                  borderWidth: 1,
                  paddingHorizontal: 25,
                }}
              >
                <Text
                  style={{
                    color: "#5a7fdf",
                  }}
                >
                  Or connect using social account
                </Text>
              </View>
            </Animatable.View>
          </ImageBackground>
        </View>
      </NativeBaseProvider>
    );
  }
}
export default SignInScreen;

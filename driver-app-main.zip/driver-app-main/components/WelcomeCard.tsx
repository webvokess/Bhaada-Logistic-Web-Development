import { Image, StyleSheet, Text, View } from "react-native";
import React from "react";
import person from "../assets/person.png";
import tw from "tailwind-react-native-classnames";
import { useSelector } from "react-redux";
import { selectDriver, selectDriverAvatar } from "../store/slices/driver";

const HelloCard = () => {
  const driver = useSelector(selectDriver);
  return (
    <View
      style={[
        tw`mx-auto bg-blue-700 mt-7 rounded-3xl px-7 pt-9`,
        { width: 350, height: 130 },
      ]}
    >
      <Text
        style={[tw`text-white text-base`, { fontFamily: "Mulish_400Regular" }]}
      >
        Good Evening,
      </Text>
      <Text
        style={[tw`text-white text-3xl`, { fontFamily: "Mulish_600SemiBold" }]}
      >
        {driver.name}
      </Text>
      <Image
        source={{
          uri: useSelector(selectDriverAvatar),
        }}
        style={[
          tw`absolute right-5 top-5 `,
          { width: 100, height: 60, resizeMode: "contain" },
        ]}
      />
    </View>
  );
};

export default HelloCard;

const styles = StyleSheet.create({});

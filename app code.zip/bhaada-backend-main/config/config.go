package config

import (
	"fmt"
	"os"
	"strconv"

	"github.com/joho/godotenv"
)

type Config struct {
	AppName string
	AppEnv  string

	RedisAddr          string
	MongoUrl           string
	MongoDb            string
	ServerPort         string
	EsURL              string
	EsPort             int
	SentryDSN          string
	SentrySamplingRate float64
}

var config Config

// Should run at the very beginning, before any other package
// or code.
func init() {
	appEnv := os.Getenv("APP_ENV")
	if len(appEnv) == 0 {
		appEnv = "dev"
	}

	configFilePath := "./config/.env.dev"

	switch appEnv {
	case "production":
		configFilePath = "./config/.env.prod"
		break
	case "stage":
		configFilePath = "./config/.env.stage"
		break
	}
	fmt.Println("reading env from: ", configFilePath)

	e := godotenv.Load(configFilePath)
	if e != nil {
		fmt.Println("error loading env: ", e)
		panic(e.Error())
	}
	config.AppName = os.Getenv("SERVICE_NAME")
	config.AppEnv = appEnv

	config.RedisAddr = os.Getenv("REDIS_ADDR")

	config.MongoUrl = os.Getenv("MONGO_URL")
	config.MongoDb = os.Getenv("MONGO_DB")

	config.ServerPort = os.Getenv("SERVER_PORT")
	config.EsURL = os.Getenv("ES_URL")
	config.EsPort, _ = strconv.Atoi(os.Getenv("ES_PORT"))
	config.SentryDSN = os.Getenv("SENTRY_DSN")
	config.SentrySamplingRate, _ = strconv.ParseFloat(os.Getenv("SENTRY_SAMPLING_RATE"), 64)
}

func Get() Config {
	return config
}

func IsProduction() bool {
	return config.AppEnv == "production"
}

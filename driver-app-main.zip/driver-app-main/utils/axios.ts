import axios from "axios";
import { useSelector } from "react-redux";
import { selectAccessToken } from "../store/slices/tokens";

export const axiosInstance = axios.create({
  baseURL: "http://api.bhaada.co.in/api/v1",
  headers: {
    Authorization: `Bearer $(selectAccessToken)`,
  },
});

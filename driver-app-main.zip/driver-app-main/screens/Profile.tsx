import { StyleSheet, Text, View, SafeAreaView, Image } from "react-native";
import React, { useState } from "react";
import Menu from "../components/Menu";
import tw from "tailwind-react-native-classnames";
import Footer from "../components/Footer";
import person from "../assets/person.png";
import { useSelector } from "react-redux";
import { selectDriver, selectDriverAvatar } from "../store/slices/driver";

const Profile = () => {
  const driver = useSelector(selectDriver);
  const [input, setInput] = useState(driver);

  const changeHandler = (name, value) => {
    setInput({ ...input, [name]: value });
  };

  return (
    <SafeAreaView>
      <Text
        style={[
          tw`mx-auto mt-10 text-xl`,
          { fontFamily: "Mulish_700Bold", color: "#3E4958" },
        ]}
      >
        Your Profile
      </Text>
      <Menu />
      <View
        style={[
          tw`mt-7 mx-auto mb-24 rounded-2xl`,
          { width: 350, height: 410, backgroundColor: "#593ff8" },
        ]}
      >
        <View
          style={[
            tw`rounded-2xl px-7 pt-9`,
            { backgroundColor: "#3016d1", height: 130 },
          ]}
        >
          <Text
            style={[
              tw`text-white text-base text-white`,
              { fontFamily: "Mulish_400Regular" },
            ]}
          >
            Good Evening,
          </Text>
          <Text
            style={[
              tw`text-white text-3xl`,
              { fontFamily: "Mulish_600SemiBold" },
            ]}
          >
            {driver.name}
          </Text>
          <Image
            source={{
              uri: useSelector(selectDriverAvatar),
            }}
            style={[
              tw`absolute right-5 top-5 `,
              { width: 100, height: 60, resizeMode: "contain" },
            ]}
          />
        </View>
        <View style={tw`py-4 px-7`}>
          <View style={tw`flex-row justify-between items-center`}>
            <View>
              <Text
                style={[
                  tw`text-base text-white`,
                  { fontFamily: "Mulish_400Regular" },
                ]}
              >
                JOINED
              </Text>
              <Text
                style={[
                  tw`text-white text-xl`,
                  { fontFamily: "Mulish_700Bold" },
                ]}
              >
                July 2022
              </Text>
            </View>
            <View>
              <Text
                style={[
                  tw`text-base text-white`,
                  { fontFamily: "Mulish_400Regular" },
                ]}
              >
                RATINGS
              </Text>
              <Text
                style={[
                  tw`text-white text-xl`,
                  { fontFamily: "Mulish_700Bold" },
                ]}
              >
                4.8 ⭐
              </Text>
            </View>
          </View>
          <View style={tw`mt-3`}>
            <Text
              style={[
                tw`text-base text-white`,
                { fontFamily: "Mulish_400Regular" },
              ]}
            >
              UPI ID
            </Text>
            <Text
              style={[tw`text-white text-xl`, { fontFamily: "Mulish_700Bold" }]}
            >
              9044597953@ybl
            </Text>
          </View>
          <View style={tw`mt-3`}>
            <Text
              style={[
                tw`text-base text-white`,
                { fontFamily: "Mulish_400Regular" },
              ]}
            >
              EMAIL ID
            </Text>
            <Text
              style={[tw`text-white text-xl`, { fontFamily: "Mulish_700Bold" }]}
            >
              {driver.email}
            </Text>
          </View>
          <View style={tw`mt-3`}>
            <Text
              style={[
                tw`text-base text-white`,
                { fontFamily: "Mulish_400Regular" },
              ]}
            >
              MOBILE NUMBER
            </Text>
            <Text
              style={[tw`text-white text-xl`, { fontFamily: "Mulish_700Bold" }]}
            >
              {driver.mobile}
            </Text>
          </View>
        </View>
      </View>
      <Footer />
    </SafeAreaView>
  );
};

export default Profile;

const styles = StyleSheet.create({});

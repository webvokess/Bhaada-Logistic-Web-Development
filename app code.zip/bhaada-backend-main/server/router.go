package server

import (
	"bhaada-backend/controller"
	"bhaada-backend/middleware"

	"github.com/gin-gonic/gin"
	"go.elastic.co/apm/module/apmgin"
)

func NewRouter() *gin.Engine {

	router := gin.New()
	router.Use(apmgin.Middleware(router))
	router.Use(gin.Logger())

	v1 := router.Group("api/v1")
	{
		v1.GET("/", func(c *gin.Context) {
			c.JSON(200, gin.H{
				"message": "pong",
			})
		})

		v1.POST("login/otp", controller.SendOtp)
		v1.POST("login/otp/verify", controller.VerifyOtp)

		v1.POST("auth/refresh", middleware.Auth, controller.RefreshToken)

		v1.POST("login/password", nil)
		v1.POST("login/password/verify", nil)

		v1.POST("register", nil)

		v1.POST("logout", nil)

		v1.GET("user/profile", nil)
		v1.POST("user/profile/update", nil)
		v1.POST("user/profile/update/password", nil)
		v1.POST("user/profile/update/email", nil)
		v1.POST("user/profile/email/verify/resend", nil)
		v1.GET("user/profile/email/verify", nil)

		v1.POST("user/profile/update/phone", nil)
		v1.POST("user/profile/phone/verify/resend", nil)
		v1.POST("user/profile/phone/verify", nil)

		// driver

		v1.POST("driver/register", nil)

		// ride

		v1.POST("ride", nil)
		v1.GET("user_ride", nil)   // userid=? & status=? & page=? & limit=? & sort=? & order=?
		v1.GET("driver_ride", nil) // driverid=? & status=? & page=? & limit=? & sort=? & order=?
		v1.GET("ride/:id", nil)

		v1.POST("ride/:id/cancel", nil)
		v1.POST("ride/:id/complete", nil)

		v1.POST("ride/:id/rate", nil)
		v1.POST("ride/:id/feedback", nil)

		v1.POST("ride/:id/start", nil)
		v1.POST("ride/:id/stop", nil)

	}

	return router
}

import { StyleSheet, Text, View } from "react-native";
import React, { useEffect, useState } from "react";
import tw from "tailwind-react-native-classnames";
import RadioButtonGroup, { RadioButtonItem } from "expo-radio-button";
import i18n from "../components/local";
import * as SecureStore from "expo-secure-store";

const Settings = () => {
  const [current, setCurrent] = useState("en");

  useEffect(() => {
    const bootstrapAsync = async () => {
      const local = i18n.locale;

      setCurrent(local);
    };

    bootstrapAsync();
  }, []);

  const handlePress = async (value) => {
    setCurrent(value);
    i18n.locale = value;

    await SecureStore.setItemAsync("local", value);
  };

  return (
    <View style={{ backgroundColor: "#a3c6f8", flex: 1 }}>
      <Text style={tw`mt-20 text-center text-3xl font-bold`}> {i18n.t('settings')} </Text>
      <Text style={tw`mt-10 ml-10 text-xl font-bold`}>
        Choose your language...
      </Text>
      <RadioButtonGroup
        containerStyle={{ marginTop: 30, marginLeft: 40 }}
        selected={current}
        onSelected={handlePress}
        radioBackground="#5745C6"
      >
        <RadioButtonItem value="en" label="English" />
        <RadioButtonItem value="hi" label="Hindi" />
      </RadioButtonGroup>
    </View>
  );
};

export default Settings;

const styles = StyleSheet.create({});

import * as Localization from "expo-localization";
import { I18n } from "i18n-js";

// Set the key-value pairs for the different languages you want to support.
const translations = {
  en: {
    welcome: "Hello",
    name: "Name",
    dashboard: "Dashboard",
    menu: "Menu",
    profile: "Profile",
    edit: "Edit",
    bookings: "Bookings",
    add: "Add",
    support: "Support",
    settings: "Settings",
    driverbooking: "Driver Booking",
    bookingdetail: "Booking Detail",
    accept: "Accepting",
    notaccept: "Not Accepting",
    eyelash: "Eyelash",
    loc: "Loc",
    logout: "Logout",
    login: "Login",
    signup: "Sign Up",
    email: "Email",
    password: "Password",
    total: "Total",
    amount: "Amount",
    cencel: "Cancel",
    confirm: "Confirm",
    payment: "Payment",
    confirmbooking: "Confirm Booking",
    confirmPayment: "Confirm Payment",
    card: "Card",
    cash: "Cash",
    pay: "Pay",
    pickup: "Pick-up",
    drop: "Drop-off",
    cargo: "Cargo",
    vehicle: "Vehicle",
    weight: "Weight",
    expectedTravelTime: "Expected Travel Time",
    expectedDistance: "Expected Distance",
    start: "Start",
    completed: "Completed",

    startPickup: "Start Pick-up",
    startDrop: "Start Drop-off",

    age: "Age",
    gender: "Gender",

    myProfile: "My Profile",
    bookingToAccept: "Booking to Accept",
    contactNumber: "Contact Number",
    vehicleType: "Vehicle Type",
    vehicleNumber: "Vehicle Number",

    vehicleModel: "Vehicle Model",
    vehicleRcDocument: "Vehicle RC Document",
    select: "Select",
    vehicleInsuranceDocument: "Vehicle Insurance Document",
    vehicleFitnessCerts: "Vehicle Fitness Certificate Document",
    enterYourName: "Enter Your Name",
    enterYourEmail: "Enter Your Email",
    enterYourQuery: "Enter Your Query",

    saveDetails: "Save Details",

    addVehicle: "Add Vehicle",
    back: "Back",

    clientName: "Client Name",
    paymentStatus: "Payment Status",
    bookingStatus: "Booking Status",
    bookingDate: "Booking Date",
    bookingTime: "Booking Time",
    bookingId: "Booking Id",
    bookingDetails: "Booking Details",
    bookingAmount: "Booking Amount",
    bookingPayment: "Booking Payment",
    bookingPaymentStatus: "Booking Payment Status",
    bookingPaymentDate: "Booking Payment Date",
    bookingPaymentTime: "Booking Payment Time",
    bookingPaymentId: "Booking Payment Id",
    bookingPaymentDetails: "Booking Payment Details",
  },
  hi: {
    welcome: "नमस्ते",
    name: "नाम",
    dashboard: "डैशबोर्ड",
    menu: "मेनू",
    profile: "प्रोफ़ाइल",
    edit: "संपादित करें",
    bookings: "बुकिंग",
    add: "जोड़ें",
    support: "समर्थन",
    settings: "सेटिंग्स",
    driverbooking: "ड्राइवर बुकिंग",
    bookingdetail: "बुकिंग विवरण",
    accept: "स्वीकार करना",
    notaccept: "स्वीकार नहीं करना",
    eyelash: "आँखों की लंबाई",
    loc: "लोक",
    logout: "लॉग आउट",
    login: "लॉग इन करें",
    signup: "साइन अप करें",
    email: "ईमेल",
    password: "पासवर्ड",
    total: "कुल",
    amount: "राशि",
    cencel: "रद्द करना",
    confirm: "पुष्टि करना",
    payment: "भुगतान",

    confirmbooking: "बुकिंग की पुष्टि करें",
    confirmPayment: "भुगतान की पुष्टि करें",

    card: "कार्ड",
    cash: "नकद",
    pay: "भुगतान",
    pickup: "उठाना",
    drop: "ड्रॉप",
    cargo: "भाड़ा",
    vehicle: "वाहन",
    weight: "वजन",
    expectedTravelTime: "अपेक्षित यात्रा समय",
    expectedDistance: "अपेक्षित दूरी",
    start: "प्रारंभ",
    completed: "पूरा हुआ",

    startPickup: "पिकअप शुरू करें",
    startDrop: "ड्रॉप शुरू करें",

    age: "आयु",

    gender: "लिंग",

    myProfile: "मेरी प्रोफ़ाइल",

    bookingToAccept: "स्वीकार करने के लिए बुकिंग",

    contactNumber: "संपर्क नंबर",

    vehicleType: "वाहन का प्रकार",

    vehicleNumber: "वाहन संख्या",

    vehicleModel: "वाहन मॉडल",

    vehicleRcDocument: "वाहन RC दस्तावेज़",

    select: "चुनते हैं",

    vehicleInsuranceDocument: "वाहन बीमा दस्तावेज़",

    vehicleFitnessCerts: "वाहन फिटनेस सर्टिफिकेट दस्तावेज़",

    enterYourName: "अपना नाम दर्ज करें",

    enterYourEmail: "अपना ईमेल दर्ज करें",

    enterYourQuery: "अपना प्रश्न दर्ज करें",

    saveDetails: "विवरण सहेजें",

    addVehicle: "वाहन जोड़ें",

    back: "वापस जाये", // go backs

    bookingPaymentTime: "बुकिंग भुगतान समय",
    bookingPaymentAmount: "बुकिंग भुगतान राशि",
    bookingPaymentStatus: "बुकिंग भुगतान स्थिति",
    bookingPaymentType: "बुकिंग भुगतान प्रकार",
    bookingPaymentDate: "बुकिंग भुगतान तिथि",
    bookingPaymentId: "बुकिंग भुगतान आईडी",
    bookingPayment: "बुकिंग भुगतान",
    bookingPaymentDetails: "बुकिंग भुगतान विवरण",


  },
};
const i18n = new I18n(translations);

// Set the locale once at the beginning of your app.
// i18n.locale = Localization.locale;

// When a value is missing from a language it'll fallback to another language with the key present.
i18n.enableFallback = true;
// To see the fallback mechanism uncomment line below to force app to use Japanese language.
// i18n.locale = 'ja';

export default i18n;

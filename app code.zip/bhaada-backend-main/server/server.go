package server

import (
	"bhaada-backend/db"
	"bhaada-backend/logger"
	"bhaada-backend/redis"
	"log"
)

func Init() {

	// cfg := config.Get()

	// err := sentry.Init(sentry.ClientOptions{
	// 	Dsn:              cfg.SentryDSN,
	// 	Debug:            true,
	// 	Environment:      cfg.AppEnv,
	// 	TracesSampleRate: cfg.SentrySamplingRate,
	// })
	// if err != nil {
	// 	log.Fatalf("sentry.Init: %s", err)
	// }
	// defer sentry.Flush(2 * time.Second)

	logger.Init()
	db.Init()
	// es.Init()
	redis.Init()

	r := NewRouter()
	err := r.Run(":" + "4000")
	if err != nil {
		log.Fatal(err)
		return
	}
}

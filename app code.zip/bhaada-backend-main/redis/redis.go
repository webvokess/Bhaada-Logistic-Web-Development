package redis

import (
	"bhaada-backend/config"
	"bhaada-backend/logger"
	"sync"

	"github.com/go-redis/redis"
)

var client *redis.Client
var once sync.Once

func Init() {
	once.Do(func() {
		clusterAdd := config.Get().RedisAddr
		client = redis.NewClient(&redis.Options{
			Addr: clusterAdd,
		})
		_, err := client.Ping().Result()
		if err != nil {
			panic(err.Error())
		}

		logger.Client().Info("Connected to Redis")
	})
}

func GetClient() *redis.Client {
	return client
}

import {
  StyleSheet,
  Text,
  View,
  SafeAreaView,
  TouchableOpacity,
  Image,
  TextInput,
  ScrollView,
} from "react-native";
import React, { Dispatch, useState } from "react";
import tw from "tailwind-react-native-classnames";
import person from "../assets/person.png";
import arrow from "../assets/arrow.png";
import { useNavigation } from "@react-navigation/native";
import {
  selectAaadharCard,
  selectDriver,
  selectDriverAvatar,
  setDriver,
} from "../store/slices/driver";
import { useDispatch, useSelector } from "react-redux";
import { axiosInstance } from "../utils/axios";
import { stringToInt } from "../utils/string";
import { AntDesign } from "@expo/vector-icons";

import * as ImagePicker from "expo-image-picker";
import i18n from "../components/local";
import { Picker } from "@react-native-picker/picker";

const AddAadharCard = () => {
  const driver = useSelector(selectDriver);
  const inputs = {
    aadharNumber: driver.aadharNumber,
    aadharCard: driver.aadharCard,
  };
  const [input, setInput] = useState(inputs);
  const changeHandler = (name: string, value: string) => {
    setInput({ ...input, [name]: value });
  };
  const navigation = useNavigation();
  const dispatch: Dispatch<any> = useDispatch();
  const [image, setImage] = useState(useSelector(selectAaadharCard));
  const avatar = useSelector(selectDriverAvatar);
  const addImage = async () => {
    let _image = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: true,
      aspect: [4, 3],
      quality: 1,
    });

    if (_image.cancelled) {
      return;
    }

    let localUri = _image.uri;
    let filename = localUri.split("/").pop();

    let match = /\.(\w+)$/.exec(filename);
    let type = match ? `image/${match[1]}` : `image`;

    let formData = new FormData();

    formData.append("file", { uri: localUri, name: filename, type });
    formData.append("folder", "driver");

    console.log(formData);

    try {
      const res = await axiosInstance.post("/upload", formData, {
        headers: {
          "Content-Type": "multipart/form-data",
        },
      });

      if (res.status === 200) {
        const image = "http://cdn.bhaada.co.in" + res.data.pathname;
        setImage(image);
        changeHandler("aadharCard", res.data.pathname);
      }
    } catch (error) {
      console.log(error.response);
    }
  };

  const saveDetail = async () => {
    try {
      console.log(input);
      console.log(driver.id);

      const res = await axiosInstance.post(
        `driver/profile/update/${driver.id}`,
        input
      );

      console.log(input);

      if (res.status === 200) {
        alert("Successfully updated");

        console.log(res.data);

        dispatch(setDriver(res.data.data));

        if (driver.aadharCard == "") {
          navigation.navigate("Aadhar");
        } else if (driver.panCard == "") {
          navigation.navigate("Pan");
        } else if (driver.drivingNumber == "") {
          navigation.navigate("License");
        } else if (driver.vehicalNumber == "") {
          navigation.navigate("Vehicle");
        } else {
          navigation.navigate("Dashboard");
        }
      }
    } catch (error) {
      console.log(error);
    }
  };
  return (
    <SafeAreaView style={[tw`flex-1`, { backgroundColor: "#eef9ff" }]}>
      <ScrollView>
        <View style={tw`flex-row items-center pt-10 px-5`}>
          <TouchableOpacity
            onPress={() => navigation.goBack()}
            style={tw`rounded-full p-2 border-gray-300 border`}
          >
            <Image source={arrow} />
          </TouchableOpacity>
          <Text style={tw`text-2xl font-bold ml-5`}> Back</Text>
        </View>
        <View>
          <View style={tw`flex-row justify-between items-center px-10 mt-3`}>
            <Text
              style={[
                tw`text-xl`,
                { color: "#3E4958", fontFamily: "Mulish_700Bold" },
              ]}
            >
              Add Your Aadhar Card
            </Text>

            <View style={imageUploaderStyles.container}>
              {avatar && (
                <Image
                  source={{ uri: avatar }}
                  style={{ width: 100, height: 60, resizeMode: "contain" }}
                />
              )}
            </View>
          </View>
          {/* Line */}
        </View>

        <View style={tw`h-0.5 border-b border-gray-300 mx-10 my-3`} />

        <View style={tw`px-10 mt-3`}>
          <Text style={tw`mt-2`}>Aadhar Number</Text>
          <TextInput
            style={tw`text-black text-lg `}
            value={input.aadharNumber}
            onChangeText={(text) => changeHandler("aadharNumber", text)}
          ></TextInput>
        </View>
        <View style={tw`h-0.5 border-b border-gray-300 mx-10 my-3`} />

        {/* display aadar card here  */}

        <View style={tw`px-10 mt-3`}>
          <Text style={tw`mt-2`}>Aadhar Card</Text>
          <TouchableOpacity
            onPress={addImage}
            style={tw`flex-row items-center justify-center border border-gray-300 rounded-lg mt-2`}
          >
            <AntDesign name="plus" size={24} color="black" />
            <Text style={tw`text-lg ml-2`}>Add Image</Text>
          </TouchableOpacity>
        </View>

        {/* display uploaded addhar card images */}

        <View style={tw` mt-3`}>
          {image && (
            <Image
              source={{ uri: image }}
              style={{ width:  400, height: 200, resizeMode: "contain" }}
            />
          )}
        </View>

        <View style={tw`h-0.5 border-b border-gray-300 mx-10 my-3`} />

        <TouchableOpacity onPress={saveDetail} style={tw`py-5`}>
          <View
            style={[
              tw`h-14 w-11/12 mx-auto rounded-2xl justify-center items-center`,
              { backgroundColor: "blue" },
            ]}
          >
            <Text
              style={[
                tw`text-white text-center text-lg`,
                { fontFamily: "Mulish_700Bold" },
              ]}
            >
              Save Details
            </Text>
          </View>
        </TouchableOpacity>
      </ScrollView>
    </SafeAreaView>
  );
};

const imageUploaderStyles = StyleSheet.create({
  container: {
    elevation: 2,
    height: 100,
    width: 100,
    backgroundColor: "#efefef",
    position: "relative",
    borderRadius: 999,
    overflow: "hidden",
  },
  uploadBtnContainer: {
    opacity: 0.7,
    position: "absolute",
    right: 0,
    bottom: 0,
    backgroundColor: "lightgrey",
  },
  uploadBtn: {
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
  },
});
export default AddAadharCard;

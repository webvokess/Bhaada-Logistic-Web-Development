import { GOOGLE_MAPS_API_KEY } from "../env";

// function to get placeid from lat and lang
export const getPlaceID = async (
  lat: number | string,
  lng: number | string
): Promise<{ placeId: string; formatted_address: string }> => {
  const url = `https://maps.googleapis.com/maps/api/geocode/json?latlng=${lat},${lng}&key=${GOOGLE_MAPS_API_KEY}`;

  const response = await fetch(url);
  const data = await response.json();

  
  const placeId = data.results[0].place_id;
  const formatted_address = data.results[0].formatted_address;

  return { placeId, formatted_address };
};

import { StyleSheet, Text, View, Image, TouchableOpacity } from "react-native";
import React from "react";
import tw from "tailwind-react-native-classnames";
import user from "../assets/user.png";
import earnings from "../assets/earnings.png";
import support from "../assets/support.png";
import { useNavigation } from "@react-navigation/native";

const Footer = () => {
  const navigation = useNavigation();
  return (
    <View style={tw`-mt-14`}>
      <View style={tw`flex-row justify-between mx-10 items-center`}>
        <View
          style={tw`items-center`}
          onPress={() => navigation.navigate("Profile")}
        >
          <Image source={user} />
          <Text style={{ fontFamily: "Mulish_400Regular" }}>Profile</Text>
        </View>
        <View style={tw`items-center`}>
          <Image source={earnings} />
          <Text style={{ fontFamily: "Mulish_400Regular" }}>Earnings</Text>
        </View>
        <TouchableOpacity onPress={() => navigation.navigate("Support")}>

        <View style={tw`items-center`}>
          <Image source={support} />
          <Text style={{ fontFamily: "Mulish_400Regular" }}>Support</Text>
        </View>

        </TouchableOpacity>
      </View>
      <View style={tw`flex-row mt-5 justify-between mx-14`}>
        <TouchableOpacity
          style={[
            tw`items-center justify-center rounded-3xl`,
            { width: 130, height: 40, backgroundColor: "#A518FBDE" },
          ]}
          onPress={() => navigation.navigate("Edit")}
        >
          <Text style={[tw`text-white`, { fontFamily: "Mulish_700Bold" }]}>
            Edit Profile
          </Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[
            tw`items-center justify-center rounded-3xl`,
            { width: 130, height: 40, backgroundColor: "#A518FBDE" },
          ]}
          onPress={() => navigation.navigate("AddVehicle")}
        >
          <Text style={[tw`text-white`, { fontFamily: "Mulish_700Bold" }]}>
            Add Vehicle
          </Text>
        </TouchableOpacity>
      </View>
      <TouchableOpacity
        style={[
          tw`justify-center items-center rounded-3xl mt-4 mx-auto`,
          { width: 330, height: 60, backgroundColor: "#5745C6" },
        ]}
        onPress={() => navigation.navigate("Bookings")}
      >
        <Text
          style={[tw`text-white text-lg`, { fontFamily: "Mulish_700Bold" }]}
        >
          Accept Bookings
        </Text>
      </TouchableOpacity>
    </View>
  );
};

export default Footer;

const styles = StyleSheet.create({});
